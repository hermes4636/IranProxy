package com.reza.iranproxy.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor

class XrayVpnService : VpnService() {

    companion object {
        private const val ACTION_START = "com.reza.iranproxy.ACTION_START"
        private const val ACTION_STOP = "com.reza.iranproxy.ACTION_STOP"
        private const val NOTIFICATION_CHANNEL_ID = "vpn_channel"
        private const val NOTIFICATION_ID = 1
        private const val VPN_ADDRESS = "10.0.0.2"
        private const val VPN_ROUTE = "0.0.0.0"
        private const val VPN_DNS = "1.1.1.1"
        private const val TUN_MTU = 1500

        private var isRunning = false

        fun start(context: Context) {
            val intent = Intent(context, XrayVpnService::class.java).apply {
                action = ACTION_START
            }
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, XrayVpnService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun isServiceRunning(): Boolean = isRunning
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var coreManager: XrayCoreManager? = null

    // ── Lifecycle ──

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        coreManager = XrayCoreManager(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                startVpn()
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    // ── VPN Start ──

    private fun startVpn() {
        try {
            // ۱. Notification
            startForeground(NOTIFICATION_ID, buildNotification())

            // ۲. ساخت TUN interface
            val builder = Builder()
                .setSession("IranProxy")
                .setMtu(TUN_MTU)
                .addAddress(VPN_ADDRESS, 32)
                .addRoute(VPN_ROUTE, 0)
                .addDnsServer(VPN_DNS)
                .addDisallowedApplication(packageName)

            vpnInterface = builder.establish()

            if (vpnInterface == null) {
                stopVpn()
                return
            }

            isRunning = true

            // ۳. اتصال Xray Core به TUN
            startProxy()

        } catch (e: Exception) {
            stopVpn()
        }
    }

    private fun stopVpn() {
        isRunning = false

        // استاپ Xray Core
        try {
            coreManager?.let { mgr ->
                if (mgr.isRunning()) mgr.stop()
            }
        } catch (_: Exception) {}

        // بستن TUN
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ── Proxy ──

    private fun startProxy() {
        val fd = vpnInterface ?: return
        // TODO: وصل کردن Xray Core به این fd
        // Xray TUN mode یا tun2socks
    }

    // ── Notification ──

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "VPN Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "وضعیت اتصال VPN"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, XrayVpnService::class.java).apply {
            action = ACTION_STOP
        }
        val pending = PendingIntent.getService(
            this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE
        )

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, NOTIFICATION_CHANNEL_ID)
                .setContentTitle("IranProxy")
                .setContentText("متصل شده")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("IranProxy")
                .setContentText("متصل شده")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        }
    }

    // ── Builder (برای VPN interface) ──

    inner class Builder : VpnService.Builder() {
        override fun establish(): ParcelFileDescriptor? {
            return super.establish()
        }
    }
}
