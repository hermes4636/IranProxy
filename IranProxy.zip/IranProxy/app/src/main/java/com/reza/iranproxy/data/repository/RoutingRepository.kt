package com.reza.iranproxy.data.repository

import com.reza.iranproxy.data.local.dao.RoutingRuleDao
import com.reza.iranproxy.data.local.entity.RoutingRuleEntity
import kotlinx.coroutines.flow.Flow

class RoutingRepository(
    private val routingRuleDao: RoutingRuleDao
) {

    // ── CRUD ──

    suspend fun insert(rule: RoutingRuleEntity): Long =
        routingRuleDao.insert(rule)

    suspend fun insertAll(rules: List<RoutingRuleEntity>): List<Long> =
        routingRuleDao.insertAll(rules)

    suspend fun update(rule: RoutingRuleEntity) =
        routingRuleDao.update(rule)

    suspend fun delete(rule: RoutingRuleEntity) =
        routingRuleDao.delete(rule)

    suspend fun deleteById(id: Long) =
        routingRuleDao.deleteById(id)

    suspend fun deleteAll() =
        routingRuleDao.deleteAll()

    // ── Get ──

    fun getAll(): Flow<List<RoutingRuleEntity>> =
        routingRuleDao.getAll()

    suspend fun getAllOnce(): List<RoutingRuleEntity> =
        routingRuleDao.getAllOnce()

    suspend fun getById(id: Long): RoutingRuleEntity? =
        routingRuleDao.getById(id)

    fun getByIdFlow(id: Long): Flow<RoutingRuleEntity?> =
        routingRuleDao.getByIdFlow(id)

    // ── Enabled ──

    fun getEnabled(): Flow<List<RoutingRuleEntity>> =
        routingRuleDao.getEnabled()

    suspend fun getEnabledOnce(): List<RoutingRuleEntity> =
        routingRuleDao.getEnabledOnce()

    // ── By Outbound ──

    fun getByOutbound(outbound: String): Flow<List<RoutingRuleEntity>> =
        routingRuleDao.getByOutbound(outbound)

    suspend fun getByOutboundOnce(outbound: String): List<RoutingRuleEntity> =
        routingRuleDao.getByOutboundOnce(outbound)

    // ── By Type ──

    fun getByType(type: String): Flow<List<RoutingRuleEntity>> =
        routingRuleDao.getByType(type)

    // ── Toggle ──

    suspend fun setEnabled(id: Long, enabled: Boolean) =
        routingRuleDao.setEnabled(id, enabled)

    suspend fun setPriority(id: Long, priority: Int) =
        routingRuleDao.setPriority(id, priority)

    suspend fun setOutbound(id: Long, outbound: String) =
        routingRuleDao.setOutbound(id, outbound)

    // ── Count ──

    fun getCount(): Flow<Int> =
        routingRuleDao.getCount()

    suspend fun getEnabledCount(): Int =
        routingRuleDao.getEnabledCount()

    suspend fun getCountByOutbound(outbound: String): Int =
        routingRuleDao.getCountByOutbound(outbound)
}
