package com.reza.iranproxy.ui.screen.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reza.iranproxy.data.repository.ServerRepository
import com.reza.iranproxy.domain.model.ConnectionStatus
import com.reza.iranproxy.domain.model.Server
import com.reza.iranproxy.domain.model.ServerProtocol
import com.reza.iranproxy.domain.usecase.ConnectUseCase
import com.reza.iranproxy.domain.usecase.DisconnectUseCase
import com.reza.iranproxy.domain.usecase.SwitchServerUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val serverRepository: ServerRepository,
    private val connectUseCase: ConnectUseCase,
    private val disconnectUseCase: DisconnectUseCase,
    private val switchServerUseCase: SwitchServerUseCase
) : ViewModel() {

    // ── Servers ──

    val servers: StateFlow<List<Server>> = serverRepository.getAllServers()
        .mapToServers()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // ── Connection Status ──

    val connectionStatus: StateFlow<ConnectionStatus> = connectUseCase.status
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ConnectionStatus.Disconnected
        )

    // ── Active Server ──

    val activeServer: StateFlow<Server?> = serverRepository.getActiveServer()
        .mapToServer()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    // ── Search ──

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredServers: StateFlow<List<Server>> = _searchQuery.flatMapLatest { query ->
        if (query.isBlank()) {
            serverRepository.getAllServers()
        } else {
            serverRepository.search(query)
        }
    }.mapToServers()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // ── Actions ──

    fun toggleConnection() {
        viewModelScope.launch {
            val currentStatus = connectUseCase.status.value

            if (currentStatus.isConnected) {
                disconnectUseCase()
            } else if (currentStatus.isDisconnected) {
                val server = activeServer.value
                if (server != null) {
                    connectUseCase(server)
                }
            }
        }
    }

    fun selectServer(server: Server) {
        viewModelScope.launch {
            switchServerUseCase(server)
        }
    }

    fun testLatency(server: Server) {
        viewModelScope.launch {
            // TODO: تست واقعی پینگ
            val fakeLatency = (50..500).random().toLong()
            serverRepository.updateLatency(server.id, fakeLatency)
        }
    }

    fun toggleFavorite(server: Server) {
        viewModelScope.launch {
            serverRepository.setFavorite(server.id, !server.isFavorite)
        }
    }

    fun updateSearch(query: String) {
        _searchQuery.value = query
    }

    // ── Mappers ──

    private fun kotlinx.coroutines.flow.Flow<List<com.reza.iranproxy.data.local.entity.ServerEntity>>.mapToServers():
            kotlinx.coroutines.flow.Flow<List<Server>> {
        return this.map { entities ->
            entities.map { it.toDomain() }
        }
    }

    private fun kotlinx.coroutines.flow.Flow<com.reza.iranproxy.data.local.entity.ServerEntity?>.mapToServer():
            kotlinx.coroutines.flow.Flow<Server?> {
        return this.map { entity ->
            entity?.toDomain()
        }
    }

    private fun com.reza.iranproxy.data.local.entity.ServerEntity.toDomain(): Server {
        return Server(
            id = id,
            name = name,
            address = address,
            port = port,
            protocol = ServerProtocol.fromString(protocol),
            uuid = uuid,
            alterId = alterId,
            password = password,
            security = security,
            network = network,
            headerType = headerType,
            host = host,
            path = path,
            tls = tls,
            sni = sni,
            fingerprint = fingerprint,
            alpn = alpn,
            flow = flow,
            realityPublicKey = realityPublicKey,
            realityShortId = realityShortId,
            subscriptionId = subscriptionId,
            isActive = isActive,
            isFavorite = isFavorite,
            latency = latency,
            trafficUsed = trafficUsed,
            trafficTotal = trafficTotal,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }
}

// ── Flow Extensions ──

private fun <T, R> kotlinx.coroutines.flow.Flow<T>.map(transform: (T) -> R): kotlinx.coroutines.flow.Flow<R> {
    return kotlinx.coroutines.flow.map(this) { transform(it) }
}

private fun <T> kotlinx.coroutines.flow.Flow<T>.flatMapLatest(transform: (T) -> kotlinx.coroutines.flow.Flow<*>): kotlinx.coroutines.flow.Flow<*> {
    return kotlinx.coroutines.flow.flatMapLatest(this) { transform(it) }
}
