package com.reza.iranproxy.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.reza.iranproxy.ui.screen.home.HomeScreen
import com.reza.iranproxy.ui.screen.servers.AddServerScreen
import com.reza.iranproxy.ui.screen.servers.ServerListScreen
import com.reza.iranproxy.ui.screen.settings.SettingsScreen
import com.reza.iranproxy.ui.screen.subscriptions.SubscriptionScreen

object Routes {
    const val HOME = "home"
    const val SERVERS = "servers"
    const val ADD_SERVER = "add_server"
    const val SUBSCRIPTIONS = "subscriptions"
    const val ROUTING = "routing"
    const val SETTINGS = "settings"
}

@Composable
fun AppNavigation(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Routes.HOME
    ) {
        // ── صفحه اصلی ──
        composable(Routes.HOME) {
            HomeScreen(
                onNavigateToServers = {
                    navController.navigate(Routes.SERVERS)
                },
                onNavigateToAddServer = {
                    navController.navigate(Routes.ADD_SERVER)
                },
                onNavigateToSettings = {
                    navController.navigate(Routes.SETTINGS)
                }
            )
        }

        // ── لیست سرورها ──
        composable(Routes.SERVERS) {
            ServerListScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToAddServer = {
                    navController.navigate(Routes.ADD_SERVER)
                }
            )
        }

        // ── افزودن سرور ──
        composable(Routes.ADD_SERVER) {
            AddServerScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // ── اشتراک‌ها ──
        composable(Routes.SUBSCRIPTIONS) {
            SubscriptionScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // ── تنظیمات ──
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // TODO: صفحات بعدی
        // composable(Routes.ROUTING) { RoutingScreen(...) }
    }
}
