package com.reza.iranproxy.domain.model

enum class ServerProtocol(val displayName: String) {
    VMESS("VMess"),
    VLESS("VLess"),
    SHADOWSOCKS("Shadowsocks"),
    TROJAN("Trojan"),
    TUIC("TUIC"),
    HYSTERIA("Hysteria"),
    HYSTERIA2("Hysteria2"),
    WIREGUARD("WireGuard");

    companion object {
        fun fromString(value: String): ServerProtocol {
            return entries.find {
                it.name.equals(value, ignoreCase = true)
            } ?: VMESS
        }
    }
}
