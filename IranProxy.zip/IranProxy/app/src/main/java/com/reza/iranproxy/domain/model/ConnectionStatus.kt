package com.reza.iranproxy.domain.model

sealed class ConnectionStatus {

    data object Disconnected : ConnectionStatus()

    data class Connecting(
        val serverId: Long,
        val serverName: String
    ) : ConnectionStatus()

    data class Connected(
        val serverId: Long,
        val serverName: String,
        val connectedAt: Long = System.currentTimeMillis(),
        val uploadSpeed: Long = 0L,
        val downloadSpeed: Long = 0L,
        val totalUpload: Long = 0L,
        val totalDownload: Long = 0L
    ) : ConnectionStatus()

    data class Error(
        val serverId: Long? = null,
        val message: String,
        val timestamp: Long = System.currentTimeMillis()
    ) : ConnectionStatus()

    // ── Helpers ──

    val isConnected: Boolean
        get() = this is Connected

    val isConnecting: Boolean
        get() = this is Connecting

    val isDisconnected: Boolean
        get() = this is Disconnected

    val isError: Boolean
        get() = this is Error
}
