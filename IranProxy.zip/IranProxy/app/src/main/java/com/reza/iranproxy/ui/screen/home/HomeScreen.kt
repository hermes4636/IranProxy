package com.reza.iranproxy.ui.screen.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.reza.iranproxy.domain.model.ConnectionStatus
import com.reza.iranproxy.domain.model.Server
import com.reza.iranproxy.domain.model.ServerProtocol
import com.reza.iranproxy.ui.theme.Blue500
import com.reza.iranproxy.ui.theme.Green500
import com.reza.iranproxy.ui.theme.Gray500
import com.reza.iranproxy.ui.theme.Orange500
import com.reza.iranproxy.ui.theme.Red500

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToServers: () -> Unit = {},
    onNavigateToAddServer: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    viewModel: HomeViewModel = hiltViewModel()
) {
    val servers by viewModel.filteredServers.collectAsState()
    val status by viewModel.connectionStatus.collectAsState()
    val activeServer by viewModel.activeServer.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("IranProxy") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "تنظیمات")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAddServer,
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "افزودن سرور")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // ── وضعیت اتصال ──
            ConnectionStatusCard(
                status = status,
                activeServer = activeServer,
                onToggleConnection = { viewModel.toggleConnection() }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── جستجو ──
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearch(it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("جستجوی سرور...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── لیست سرورها ──
            Text(
                text = "سرورها (${servers.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (servers.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(servers) { server ->
                        ServerCard(
                            server = server,
                            isActive = server.isActive,
                            onClick = { viewModel.selectServer(server) },
                            onFavorite = { viewModel.toggleFavorite(server) },
                            onTestLatency = { viewModel.testLatency(server) }
                        )
                    }
                }
            }
        }
    }
}

// ── Connection Status Card ──

@Composable
private fun ConnectionStatusCard(
    status: ConnectionStatus,
    activeServer: Server?,
    onToggleConnection: () -> Unit
) {
    val backgroundColor by animateColorAsState(
        targetValue = when (status) {
            is ConnectionStatus.Connected -> Green500
            is ConnectionStatus.Connecting -> Orange500
            is ConnectionStatus.Error -> Red500
            is ConnectionStatus.Disconnected -> MaterialTheme.colorScheme.surfaceVariant
        }
    )

    val buttonText = when (status) {
        is ConnectionStatus.Connected -> "قطع اتصال"
        is ConnectionStatus.Connecting -> "در حال اتصال..."
        is ConnectionStatus.Disconnected -> "اتصال"
        is ConnectionStatus.Error -> "تلاش مجدد"
    }

    val statusText = when (status) {
        is ConnectionStatus.Connected -> "متصل به ${status.serverName}"
        is ConnectionStatus.Connecting -> "در حال اتصال به ${status.serverName}..."
        is ConnectionStatus.Disconnected -> "قطع شده"
        is ConnectionStatus.Error -> "خطا: ${status.message}"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onToggleConnection() },
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // آیکون اتصال
            Surface(
                modifier = Modifier.size(64.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.2f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when (status) {
                            is ConnectionStatus.Connected -> Icons.Default.Star
                            else -> Icons.Default.Star
                        },
                        contentDescription = null,
                        modifier = Modifier.size(32.dp),
                        tint = MaterialTheme.colorScheme.surface
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = statusText,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.surface
            )

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onToggleConnection() },
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.2f),
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = buttonText,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.surface
                )
            }

            // نمایش ترافیک
            if (status is ConnectionStatus.Connected) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "↑ ${formatBytes(status.totalUpload)}  ↓ ${formatBytes(status.totalDownload)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                )
            }
        }
    }
}

// ── Server Card ──

@Composable
private fun ServerCard(
    server: Server,
    isActive: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit,
    onTestLatency: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = if (isActive)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // پروتکل
            Surface(
                modifier = Modifier.size(40.dp),
                shape = RoundedCornerShape(8.dp),
                color = getProtocolColor(server.protocol).copy(alpha = 0.15f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = server.protocolDisplayName.take(2),
                        style = MaterialTheme.typography.labelLarge,
                        color = getProtocolColor(server.protocol),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // اطلاعات سرور
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = server.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (isActive) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Green500
                        ) {
                            Text(
                                text = "فعال",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.surface
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${server.address}:${server.port} • ${server.tlsDisplayName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Gray500,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // پینگ
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onTestLatency() },
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Text(
                    text = server.latencyDisplay,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = getLatencyColor(server.latency)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // علاقه‌مندی
            IconButton(
                onClick = { onFavorite() },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = if (server.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "علاقه‌مندی",
                    tint = if (server.isFavorite) Red500 else Gray500,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

// ── Empty State ──

@Composable
private fun EmptyState() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = " سروری اضافه نشده",
                style = MaterialTheme.typography.titleMedium,
                color = Gray500
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "روی + کلیک کنید تا سرور اضافه کنید",
                style = MaterialTheme.typography.bodySmall,
                color = Gray500
            )
        }
    }
}

// ── Helpers ──

private fun getProtocolColor(protocol: ServerProtocol) = when (protocol) {
    ServerProtocol.VMESS -> Blue500
    ServerProtocol.VLESS -> Green500
    ServerProtocol.SHADOWSOCKS -> Orange500
    ServerProtocol.TROJAN -> Red500
    ServerProtocol.TUIC -> Blue500
    ServerProtocol.HYSTERIA -> Orange500
    ServerProtocol.HYSTERIA2 -> Orange500
    ServerProtocol.WIREGUARD -> Green500
}

private fun getLatencyColor(latency: Long) = when {
    latency < 0 -> Gray500
    latency < 100 -> Green500
    latency < 300 -> Orange500
    else -> Red500
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    if (bytes < 1024 * 1024) return "${bytes / 1024} KB"
    if (bytes < 1024 * 1024 * 1024) return "${bytes / (1024 * 1024)} MB"
    return "${bytes / (1024 * 1024 * 1024)} GB"
}
