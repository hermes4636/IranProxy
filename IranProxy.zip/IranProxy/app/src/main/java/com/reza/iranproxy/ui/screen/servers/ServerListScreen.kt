package com.reza.iranproxy.ui.screen.servers

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.reza.iranproxy.domain.model.Server
import com.reza.iranproxy.domain.model.ServerProtocol
import com.reza.iranproxy.ui.theme.Blue500
import com.reza.iranproxy.ui.theme.Green500
import com.reza.iranproxy.ui.theme.Gray500
import com.reza.iranproxy.ui.theme.Orange500
import com.reza.iranproxy.ui.theme.Red500

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerListScreen(
    onNavigateBack: () -> Unit = {},
    onNavigateToAddServer: () -> Unit = {},
    viewModel: ServerListViewModel = hiltViewModel()
) {
    val servers by viewModel.filteredServers.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedProtocol by viewModel.selectedProtocol.collectAsState()
    val sortBy by viewModel.sortBy.collectAsState()

    var showDeleteDialog by remember { mutableStateOf<Server?>(null) }

    // فیلتر و مرتب‌سازی
    val displayedServers = servers
        .filter { server ->
            if (searchQuery.isBlank()) true
            else server.name.contains(searchQuery, ignoreCase = true) ||
                    server.address.contains(searchQuery, ignoreCase = true)
        }
        .filter { server ->
            selectedProtocol == null || server.protocol == selectedProtocol
        }
        .let { list ->
            when (sortBy) {
                ServerListViewModel.SortBy.NAME -> list.sortedBy { it.name }
                ServerListViewModel.SortBy.LATENCY -> list.sortedBy { it.latency }
                ServerListViewModel.SortBy.PROTOCOL -> list.sortedBy { it.protocol.name }
            }
        }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("لیست سرورها") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.testAllLatencies() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تست همه")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAddServer,
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "افزودن سرور")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // ── جستجو ──
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearch(it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("جستجو...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // ── فیلتر پروتکل ──
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedProtocol == null,
                        onClick = { viewModel.selectProtocol(null) },
                        label = { Text("همه") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
                items(ServerProtocol.entries.take(4)) { proto ->
                    FilterChip(
                        selected = selectedProtocol == proto,
                        onClick = {
                            viewModel.selectProtocol(
                                if (selectedProtocol == proto) null else proto
                            )
                        },
                        label = { Text(proto.displayName) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = getProtocolColor(proto).copy(alpha = 0.15f)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ── مرتب‌سازی ──
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SortButton("نام", sortBy == ServerListViewModel.SortBy.NAME) {
                    viewModel.selectSort(ServerListViewModel.SortBy.NAME)
                }
                SortButton("پینگ", sortBy == ServerListViewModel.SortBy.LATENCY) {
                    viewModel.selectSort(ServerListViewModel.SortBy.LATENCY)
                }
                SortButton("پروتکل", sortBy == ServerListViewModel.SortBy.PROTOCOL) {
                    viewModel.selectSort(ServerListViewModel.SortBy.PROTOCOL)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ── تعداد ──
            Text(
                text = "${displayedServers.size} سرور",
                style = MaterialTheme.typography.bodySmall,
                color = Gray500
            )

            Spacer(modifier = Modifier.height(8.dp))

            // ── لیست ──
            if (displayedServers.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(displayedServers) { server ->
                        ServerListItem(
                            server = server,
                            onSelect = { viewModel.selectServer(server) },
                            onFavorite = { viewModel.toggleFavorite(server) },
                            onTestLatency = { viewModel.testLatency(server) },
                            onDelete = { showDeleteDialog = server }
                        )
                    }
                }
            }
        }
    }

    // ── Dialog حذف ──
    showDeleteDialog?.let { server ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("حذف سرور") },
            text = { Text("آیا مطمئنید سرور \"${server.name}\" حذف شود؟") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteServer(server)
                    showDeleteDialog = null
                }) {
                    Text("حذف", color = Red500)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text("لغو")
                }
            }
        )
    }
}

// ── Server List Item ──

@Composable
private fun ServerListItem(
    server: Server,
    onSelect: () -> Unit,
    onFavorite: () -> Unit,
    onTestLatency: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onSelect() },
        colors = CardDefaults.cardColors(
            containerColor = if (server.isActive)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // پروتکل
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(10.dp),
                color = getProtocolColor(server.protocol).copy(alpha = 0.15f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = server.protocolDisplayName.take(2),
                        style = MaterialTheme.typography.labelLarge,
                        color = getProtocolColor(server.protocol),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // اطلاعات
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = server.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (server.isActive) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Green500
                        ) {
                            Text(
                                text = "فعال",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.surface
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${server.address}:${server.port}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Gray500,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // پینگ
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onTestLatency() },
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Text(
                    text = server.latencyDisplay,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = getLatencyColor(server.latency)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // علاقه‌مندی
            IconButton(
                onClick = { onFavorite() },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = if (server.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = null,
                    tint = if (server.isFavorite) Red500 else Gray500,
                    modifier = Modifier.size(18.dp)
                )
            }

            // حذف
            IconButton(
                onClick = { onDelete() },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "حذف",
                    tint = Gray500,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// ── Sort Button ──

@Composable
private fun SortButton(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected)
            MaterialTheme.colorScheme.primaryContainer
        else
            MaterialTheme.colorScheme.surfaceVariant
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (isSelected)
                MaterialTheme.colorScheme.primary
            else
                Gray500
        )
    }
}

// ── Empty State ──

@Composable
private fun EmptyState() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "سروری یافت نشد",
                style = MaterialTheme.typography.titleMedium,
                color = Gray500
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "فیلترها را تغییر دهید یا سرور جدید اضافه کنید",
                style = MaterialTheme.typography.bodySmall,
                color = Gray500
            )
        }
    }
}

// ── Helpers ──

private fun getProtocolColor(protocol: ServerProtocol) = when (protocol) {
    ServerProtocol.VMESS -> Blue500
    ServerProtocol.VLESS -> Green500
    ServerProtocol.SHADOWSOCKS -> Orange500
    ServerProtocol.TROJAN -> Red500
    ServerProtocol.TUIC -> Blue500
    ServerProtocol.HYSTERIA -> Orange500
    ServerProtocol.HYSTERIA2 -> Orange500
    ServerProtocol.WIREGUARD -> Green500
}

private fun getLatencyColor(latency: Long) = when {
    latency < 0 -> Gray500
    latency < 100 -> Green500
    latency < 300 -> Orange500
    else -> Red500
}
