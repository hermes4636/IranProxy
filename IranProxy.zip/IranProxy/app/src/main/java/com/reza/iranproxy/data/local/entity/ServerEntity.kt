package com.reza.iranproxy.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "servers",
    indices = [
        Index("subscription_id"),
        Index("is_active"),
        Index("protocol")
    ]
)
data class ServerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "address")
    val address: String,

    @ColumnInfo(name = "port")
    val port: Int,

    @ColumnInfo(name = "protocol")
    val protocol: String,

    @ColumnInfo(name = "uuid")
    val uuid: String = "",

    @ColumnInfo(name = "alter_id")
    val alterId: Int = 0,

    @ColumnInfo(name = "password")
    val password: String = "",

    @ColumnInfo(name = "security")
    val security: String = "",

    @ColumnInfo(name = "network")
    val network: String = "tcp",

    @ColumnInfo(name = "header_type")
    val headerType: String = "none",

    @ColumnInfo(name = "host")
    val host: String = "",

    @ColumnInfo(name = "path")
    val path: String = "",

    @ColumnInfo(name = "tls")
    val tls: String = "none",

    @ColumnInfo(name = "sni")
    val sni: String = "",

    @ColumnInfo(name = "fingerprint")
    val fingerprint: String = "chrome",

    @ColumnInfo(name = "alpn")
    val alpn: String = "",

    @ColumnInfo(name = "flow")
    val flow: String = "",

    @ColumnInfo(name = "reality_public_key")
    val realityPublicKey: String = "",

    @ColumnInfo(name = "reality_short_id")
    val realityShortId: String = "",

    @ColumnInfo(name = "subscription_id")
    val subscriptionId: Long? = null,

    @ColumnInfo(name = "is_active")
    val isActive: Boolean = false,

    @ColumnInfo(name = "is_favorite")
    val isFavorite: Boolean = false,

    @ColumnInfo(name = "latency")
    val latency: Long = -1L,

    @ColumnInfo(name = "traffic_used")
    val trafficUsed: Long = 0L,

    @ColumnInfo(name = "traffic_total")
    val trafficTotal: Long = 0L,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)
