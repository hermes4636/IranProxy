package com.reza.iranproxy.ui.screen.servers

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.reza.iranproxy.domain.model.ServerProtocol

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddServerScreen(
    onNavigateBack: () -> Unit = {},
    viewModel: AddServerViewModel = hiltViewModel()
) {
    val name by viewModel.name.collectAsState()
    val address by viewModel.address.collectAsState()
    val port by viewModel.port.collectAsState()
    val protocol by viewModel.protocol.collectAsState()
    val uuid by viewModel.uuid.collectAsState()
    val alterId by viewModel.alterId.collectAsState()
    val password by viewModel.password.collectAsState()
    val security by viewModel.security.collectAsState()
    val network by viewModel.network.collectAsState()
    val headerType by viewModel.headerType.collectAsState()
    val host by viewModel.host.collectAsState()
    val path by viewModel.path.collectAsState()
    val tls by viewModel.tls.collectAsState()
    val sni by viewModel.sni.collectAsState()
    val fingerprint by viewModel.fingerprint.collectAsState()
    val alpn by viewModel.alpn.collectAsState()
    val flow by viewModel.flow.collectAsState()
    val realityPublicKey by viewModel.realityPublicKey.collectAsState()
    val realityShortId by viewModel.realityShortId.collectAsState()
    val isSaving by viewModel.isSaving.collectAsState()
    val saveResult by viewModel.saveResult.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(saveResult) {
        when (val result = saveResult) {
            is AddServerViewModel.SaveResult.Success -> {
                snackbarHostState.showSnackbar("سرور ${result.server.name} ذخیره شد")
                onNavigateBack()
            }
            is AddServerViewModel.SaveResult.Error -> {
                snackbarHostState.showSnackbar(result.message)
            }
            is AddServerViewModel.SaveResult.Idle -> {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("افزودن سرور") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // ── اطلاعات پایه ──
            SectionTitle("اطلاعات پایه")

            CustomTextField(
                value = name,
                onValueChange = { viewModel.updateName(it) },
                label = "نام سرور",
                placeholder = "مثلاً: سرور آلمان"
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CustomTextField(
                    value = address,
                    onValueChange = { viewModel.updateAddress(it) },
                    label = "آدرس",
                    placeholder = "IP یا دامنه",
                    modifier = Modifier.weight(1f)
                )
                CustomTextField(
                    value = port,
                    onValueChange = { viewModel.updatePort(it) },
                    label = "پورت",
                    placeholder = "443",
                    modifier = Modifier.width(100.dp)
                )
            }

            // ── انتخاب پروتکل ──
            SectionTitle("پروتکل")

            SingleChoiceSegmentedButtonRow(
                modifier = Modifier.fillMaxWidth()
            ) {
                ServerProtocol.entries.take(4).forEachIndexed { index, proto ->
                    SegmentedButton(
                        selected = protocol == proto,
                        onClick = { viewModel.updateProtocol(proto) },
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            count = 4
                        )
                    ) {
                        Text(proto.displayName)
                    }
                }
            }

            // ── فیلدهای پروتکل ──
            when (protocol) {
                ServerProtocol.VMESS, ServerProtocol.VLESS -> {
                    CustomTextField(
                        value = uuid,
                        onValueChange = { viewModel.updateUuid(it) },
                        label = "UUID",
                        placeholder = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                    )
                    if (protocol == ServerProtocol.VMESS) {
                        CustomTextField(
                            value = alterId,
                            onValueChange = { viewModel.updateAlterId(it) },
                            label = "Alter ID",
                            placeholder = "0"
                        )
                    }
                    if (protocol == ServerProtocol.VLESS) {
                        CustomTextField(
                            value = flow,
                            onValueChange = { viewModel.updateFlow(it) },
                            label = "Flow",
                            placeholder = "xtls-rprx-vision"
                        )
                    }
                }
                ServerProtocol.SHADOWSOCKS, ServerProtocol.TROJAN -> {
                    CustomTextField(
                        value = password,
                        onValueChange = { viewModel.updatePassword(it) },
                        label = "Password",
                        placeholder = "رمز عبور"
                    )
                }
                else -> {}
            }

            // ── شبکه ──
            SectionTitle("شبکه")

            SingleChoiceSegmentedButtonRow(
                modifier = Modifier.fillMaxWidth()
            ) {
                val networks = listOf("tcp", "ws", "grpc")
                networks.forEachIndexed { index, net ->
                    SegmentedButton(
                        selected = network == net,
                        onClick = { viewModel.updateNetwork(net) },
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            count = networks.size
                        )
                    ) {
                        Text(net.uppercase())
                    }
                }
            }

            AnimatedVisibility(visible = network == "ws") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CustomTextField(
                        value = host,
                        onValueChange = { viewModel.updateHost(it) },
                        label = "Host",
                        placeholder = "example.com"
                    )
                    CustomTextField(
                        value = path,
                        onValueChange = { viewModel.updatePath(it) },
                        label = "Path",
                        placeholder = "/"
                    )
                }
            }

            AnimatedVisibility(visible = network == "grpc") {
                CustomTextField(
                    value = host,
                    onValueChange = { viewModel.updateHost(it) },
                    label = "Service Name",
                    placeholder = "grpcService"
                )
            }

            // ── TLS ──
            SectionTitle("TLS / امنیت")

            SingleChoiceSegmentedButtonRow(
                modifier = Modifier.fillMaxWidth()
            ) {
                val tlsOptions = listOf("none", "tls", "reality")
                tlsOptions.forEachIndexed { index, tlsOpt ->
                    SegmentedButton(
                        selected = tls == tlsOpt,
                        onClick = { viewModel.updateTls(tlsOpt) },
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            count = tlsOptions.size
                        )
                    ) {
                        Text(tlsOpt.uppercase())
                    }
                }
            }

            AnimatedVisibility(visible = tls == "tls") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CustomTextField(
                        value = sni,
                        onValueChange = { viewModel.updateSni(it) },
                        label = "SNI",
                        placeholder = "example.com"
                    )
                    CustomTextField(
                        value = fingerprint,
                        onValueChange = { viewModel.updateFingerprint(it) },
                        label = "Fingerprint",
                        placeholder = "chrome"
                    )
                    CustomTextField(
                        value = alpn,
                        onValueChange = { viewModel.updateAlpn(it) },
                        label = "ALPN",
                        placeholder = "h2,http/1.1"
                    )
                }
            }

            AnimatedVisibility(visible = tls == "reality") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CustomTextField(
                        value = sni,
                        onValueChange = { viewModel.updateSni(it) },
                        label = "SNI (Server Name)",
                        placeholder = "example.com"
                    )
                    CustomTextField(
                        value = fingerprint,
                        onValueChange = { viewModel.updateFingerprint(it) },
                        label = "Fingerprint",
                        placeholder = "chrome"
                    )
                    CustomTextField(
                        value = realityPublicKey,
                        onValueChange = { viewModel.updateRealityPublicKey(it) },
                        label = "Reality Public Key",
                        placeholder = "xxxxxxxxxxxxxxxx"
                    )
                    CustomTextField(
                        value = realityShortId,
                        onValueChange = { viewModel.updateRealityShortId(it) },
                        label = "Reality Short ID",
                        placeholder = "xxxxxxxx"
                    )
                }
            }

            // ── رمزنگاری (فقط SS) ──
            AnimatedVisibility(visible = protocol == ServerProtocol.SHADOWSOCKS) {
                Column {
                    SectionTitle("رمزنگاری")
                    SingleChoiceSegmentedButtonRow(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val methods = listOf("aes-256-gcm", "chacha20-poly1305", "auto")
                        methods.forEachIndexed { index, method ->
                            SegmentedButton(
                                selected = security == method,
                                onClick = { viewModel.updateSecurity(method) },
                                shape = SegmentedButtonDefaults.itemShape(
                                    index = index,
                                    count = methods.size
                                )
                            ) {
                                Text(method)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ── دکمه ذخیره ──
            Button(
                onClick = { viewModel.save() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                enabled = viewModel.isFormValid() && !isSaving,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (isSaving) "در حال ذخیره..." else "ذخیره سرور",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

// ── Components ──

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
private fun CustomTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        singleLine = true,
        shape = RoundedCornerShape(12.dp)
    )
}
