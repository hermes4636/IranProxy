package com.reza.iranproxy.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.reza.iranproxy.data.local.dao.RoutingRuleDao
import com.reza.iranproxy.data.local.dao.ServerDao
import com.reza.iranproxy.data.local.dao.SubscriptionDao
import com.reza.iranproxy.data.local.entity.RoutingRuleEntity
import com.reza.iranproxy.data.local.entity.ServerEntity
import com.reza.iranproxy.data.local.entity.SubscriptionEntity

@Database(
    entities = [
        ServerEntity::class,
        SubscriptionEntity::class,
        RoutingRuleEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun serverDao(): ServerDao
    abstract fun subscriptionDao(): SubscriptionDao
    abstract fun routingRuleDao(): RoutingRuleDao

    companion object {
        private const val DATABASE_NAME = "iranproxy.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
