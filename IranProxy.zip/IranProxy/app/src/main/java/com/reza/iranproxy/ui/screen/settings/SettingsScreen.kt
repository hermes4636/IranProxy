package com.reza.iranproxy.ui.screen.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.reza.iranproxy.ui.theme.Gray500
import com.reza.iranproxy.ui.theme.Green500
import com.reza.iranproxy.ui.theme.Red500

// ══════════════════════════════════════════════════════════════
//  صفحه تنظیمات
// ══════════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit = {},
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val dnsServer by viewModel.dnsServer.collectAsState()
    val tunEnabled by viewModel.tunEnabled.collectAsState()
    val bypassIran by viewModel.bypassIran.collectAsState()
    val message by viewModel.message.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()
    val showClearDataDialog by viewModel.showClearDataDialog.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // ── بخش DNS ──

            SectionHeader(title = "DNS")

            DnsSection(
                currentDns = dnsServer,
                onDnsSelected = { viewModel.setDnsServer(it) }
            )

            // ── بخش TUN ──

            SectionHeader(title = "اتصال")

            TunSection(
                enabled = tunEnabled,
                onToggle = { viewModel.toggleTun() }
            )

            // ── بخش روتینگ ──

            SectionHeader(title = "روتینگ")

            BypassIranSection(
                enabled = bypassIran,
                onToggle = { viewModel.toggleBypassIran() }
            )

            // ── بخش مدیریت ──

            SectionHeader(title = "مدیریت")

            ManagementSection(
                onClearCache = { viewModel.showClearDataDialog() },
                onResetSettings = { viewModel.showResetDialog() }
            )

            // ── نسخه ──

            VersionSection()

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // ── دیالوگ ریست ──

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.hideResetDialog() },
            icon = {
                Icon(
                    Icons.Default.Warning,
                    contentDescription = null,
                    tint = Red500
                )
            },
            title = { Text("بازگشت تنظیمات") },
            text = { Text("آیا مطمئنید تمام تنظیمات به حالت پیش‌فرض بازگردند؟") },
            confirmButton = {
                TextButton(onClick = { viewModel.resetSettings() }) {
                    Text("بازگشت", color = Red500)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.hideResetDialog() }) {
                    Text("لغو")
                }
            }
        )
    }

    // ── دیالوگ پاک کردن کش ──

    if (showClearDataDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.hideClearDataDialog() },
            icon = {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = null,
                    tint = Red500
                )
            },
            title = { Text("پاک کردن کش") },
            text = { Text("پینگ سرورها و اطلاعات موقت پاک خواهند شد. اشتراک‌ها و سرورها حفظ می‌شوند.") },
            confirmButton = {
                TextButton(onClick = { viewModel.clearCache() }) {
                    Text("پاک کردن", color = Red500)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.hideClearDataDialog() }) {
                    Text("لغو")
                }
            }
        )
    }
}

// ══════════════════════════════════════════════════════════════
//  بخش DNS
// ══════════════════════════════════════════════════════════════

@Composable
private fun DnsSection(
    currentDns: String,
    onDnsSelected: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            SettingsViewModel.DNS_OPTIONS.forEach { (dns, name) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onDnsSelected(dns) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = currentDns == dns,
                        onClick = { onDnsSelected(dns) },
                        colors = RadioButtonDefaults.colors(
                            selectedColor = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = name,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = dns.substringAfter("://").take(20),
                        style = MaterialTheme.typography.bodySmall,
                        color = Gray500
                    )
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
//  بخش TUN Mode
// ══════════════════════════════════════════════════════════════

@Composable
private fun TunSection(
    enabled: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "TUN Mode",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "ترافیک تمام اپلیکیشن‌ها از پروکسی عبور می‌کند",
                        style = MaterialTheme.typography.bodySmall,
                        color = Gray500
                    )
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = Green500
                    )
                )
            }

            if (enabled) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                ) {
                    Text(
                        text = "⚠ نیاز به دسترسی VPN دارد. تمام ترافیک دستگاه از تونل عبور می‌کند.",
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
//  بخش بایپس ایران
// ══════════════════════════════════════════════════════════════

@Composable
private fun BypassIranSection(
    enabled: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "بایپس ایران",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "ترافیک سایت‌های ایرانی مستقیم ارسال شود",
                        style = MaterialTheme.typography.bodySmall,
                        color = Gray500
                    )
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = Green500
                    )
                )
            }

            if (enabled) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "قوانین فعال:",
                    style = MaterialTheme.typography.labelMedium,
                    color = Gray500
                )
                Spacer(modifier = Modifier.height(6.dp))

                val rules = listOf(
                    "🌍  GEOIP ir → مستقیم",
                    "🌐  DOMAIN-SUFFIX .ir → مستقیم",
                    "🏠  localhost → مستقیم",
                    "📡  LAN (10.x / 172.16.x / 192.168.x) → مستقیم"
                )
                rules.forEach { rule ->
                    Text(
                        text = rule,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
//  بخش مدیریت
// ══════════════════════════════════════════════════════════════

@Composable
private fun ManagementSection(
    onClearCache: () -> Unit,
    onResetSettings: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(4.dp)) {
            // پاک کردن کش
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClearCache() }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "پاک کردن کش",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "ریست پینگ و اطلاعات موقت",
                        style = MaterialTheme.typography.bodySmall,
                        color = Gray500
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            )

            // ریست تنظیمات
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onResetSettings() }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp),
                    tint = Red500
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "بازگشت تنظیمات",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = Red500
                    )
                    Text(
                        text = "حذف تمام تنظیمات و بازگشت به حالت پیش‌فرض",
                        style = MaterialTheme.typography.bodySmall,
                        color = Gray500
                    )
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
//  نسخه اپ
// ══════════════════════════════════════════════════════════════

@Composable
private fun VersionSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "IranProxy",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "نسخه ${SettingsViewModel.APP_VERSION}",
            style = MaterialTheme.typography.bodySmall,
            color = Gray500
        )
    }
}

// ══════════════════════════════════════════════════════════════
//  هدر بخش
// ══════════════════════════════════════════════════════════════

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}
