package com.reza.iranproxy.ui.screen.settings

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reza.iranproxy.data.local.entity.RoutingRuleEntity
import com.reza.iranproxy.data.repository.RoutingRepository
import com.reza.iranproxy.data.repository.ServerRepository
import com.reza.iranproxy.data.repository.SubscriptionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

// ══════════════════════════════════════════════════════════════
//  ViewModel تنظیمات
//  ذخیره‌سازی: SharedPreferences
// ══════════════════════════════════════════════════════════════

@HiltViewModel
class SettingsViewModel @Inject constructor(
    application: Application,
    private val serverRepository: ServerRepository,
    private val subscriptionRepository: SubscriptionRepository,
    private val routingRepository: RoutingRepository
) : ViewModel() {

    private val prefs = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ── DNS ──

    private val _dnsServer = MutableStateFlow(
        prefs.getString(KEY_DNS, DNS_DEFAULT) ?: DNS_DEFAULT
    )
    val dnsServer: StateFlow<String> = _dnsServer.asStateFlow()

    // ── TUN Mode ──

    private val _tunEnabled = MutableStateFlow(prefs.getBoolean(KEY_TUN, false))
    val tunEnabled: StateFlow<Boolean> = _tunEnabled.asStateFlow()

    // ── بایپس ایران ──

    private val _bypassIran = MutableStateFlow(prefs.getBoolean(KEY_BYPASS_IRAN, true))
    val bypassIran: StateFlow<Boolean> = _bypassIran.asStateFlow()

    // ── وضعیت عملیات ──

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _showResetDialog = MutableStateFlow(false)
    val showResetDialog: StateFlow<Boolean> = _showResetDialog.asStateFlow()

    private val _showClearDataDialog = MutableStateFlow(false)
    val showClearDataDialog: StateFlow<Boolean> = _showClearDataDialog.asStateFlow()

    // ══════════════════════════════════════════════════════════
    //  عملیات
    // ══════════════════════════════════════════════════════════

    // ── DNS ──

    fun setDnsServer(dns: String) {
        val validated = dns.trim()
        if (validated.isBlank()) return
        _dnsServer.value = validated
        prefs.edit().putString(KEY_DNS, validated).apply()
    }

    // ── TUN Mode ──

    fun toggleTun() {
        val next = !_tunEnabled.value
        _tunEnabled.value = next
        prefs.edit().putBoolean(KEY_TUN, next).apply()
    }

    // ── بایپس ایران ──

    fun toggleBypassIran() {
        val next = !_bypassIran.value
        _bypassIran.value = next
        prefs.edit().putBoolean(KEY_BYPASS_IRAN, next).apply()

        viewModelScope.launch {
            applyBypassIranRules(next)
        }
    }

    // ── پاک کردن کش ──

    fun showClearDataDialog() {
        _showClearDataDialog.value = true
    }

    fun hideClearDataDialog() {
        _showClearDataDialog.value = false
    }

    fun clearCache() {
        _showClearDataDialog.value = false

        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                serverRepository.resetAllLatencies()
            }
        }

        _message.value = "کش پاک شد"
    }

    // ── ریست تنظیمات ──

    fun showResetDialog() {
        _showResetDialog.value = true
    }

    fun hideResetDialog() {
        _showResetDialog.value = false
    }

    fun resetSettings() {
        _showResetDialog.value = false

        // بازگشت به مقادیر پیش‌فرض
        _dnsServer.value = DNS_DEFAULT
        _tunEnabled.value = false
        _bypassIran.value = true

        prefs.edit().clear().apply()

        _message.value = "تنظیمات به حالت پیش‌فرض بازگشت"
    }

    // ── پاک کردن پیام ──

    fun clearMessage() {
        _message.value = null
    }

    // ══════════════════════════════════════════════════════════
    //  منطق بایپس ایران
    // ══════════════════════════════════════════════════════════

    private suspend fun applyBypassIranRules(enabled: Boolean) {
        withContext(Dispatchers.IO) {
            if (enabled) {
                // اضافه کردن قوانین بایپس ایران اگر وجود ندارند
                val existingRules = routingRepository.getByOutboundOnce("direct")
                    .filter { it.value in IRAN_BYPASS_VALUES }

                if (existingRules.isEmpty()) {
                    val iranRules = listOf(
                        RoutingRuleEntity(
                            name = "بایپس IP ایران",
                            type = "GEOIP",
                            value = "ir",
                            outbound = "direct",
                            priority = 0
                        ),
                        RoutingRuleEntity(
                            name = "بایپس دامنه‌های .ir",
                            type = "DOMAIN-SUFFIX",
                            value = "ir",
                            outbound = "direct",
                            priority = 1
                        ),
                        RoutingRuleEntity(
                            name = "بایپس localhost",
                            type = "DOMAIN",
                            value = "localhost",
                            outbound = "direct",
                            priority = 2
                        ),
                        RoutingRuleEntity(
                            name = "بایپس LAN",
                            type = "IP-CIDR",
                            value = "10.0.0.0/8",
                            outbound = "direct",
                            priority = 3
                        ),
                        RoutingRuleEntity(
                            name = "بایپس LAN",
                            type = "IP-CIDR",
                            value = "172.16.0.0/12",
                            outbound = "direct",
                            priority = 4
                        ),
                        RoutingRuleEntity(
                            name = "بایپس LAN",
                            type = "IP-CIDR",
                            value = "192.168.0.0/16",
                            outbound = "direct",
                            priority = 5
                        )
                    )
                    routingRepository.insertAll(iranRules)
                }
            } else {
                // حذف قوانین بایپس ایران
                val iranRules = routingRepository.getByOutboundOnce("direct")
                    .filter { it.value in IRAN_BYPASS_VALUES }
                iranRules.forEach { routingRepository.deleteById(it.id) }
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    //  ثابت‌ها
    // ══════════════════════════════════════════════════════════

    companion object {
        private const val PREFS_NAME = "iranproxy_settings"
        private const val KEY_DNS = "dns_server"
        private const val KEY_TUN = "tun_enabled"
        private const val KEY_BYPASS_IRAN = "bypass_iran"

        const val DNS_DEFAULT = "https://dns.google/dns-query"
        const val DNS_GOOGLE = "https://dns.google/dns-query"
        const val DNS_CLOUDFLARE = "https://cloudflare-dns.com/dns-query"
        const val DNS_ADGUARD = "https://dns.adguard.com/dns-query"
        const val DNS_403 = "https://403.online/dns-query"
        const val DNS_SHIELD = "https://dns.shield-forest.workers.dev/dns-query"

        val DNS_OPTIONS = listOf(
            DNS_GOOGLE to "Google DNS",
            DNS_CLOUDFLARE to "Cloudflare DNS",
            DNS_ADGUARD to "AdGuard DNS",
            DNS_403 to "403 DNS",
            DNS_SHIELD to "Shield Forest DNS"
        )

        const val APP_VERSION = "1.0.0"

        private val IRAN_BYPASS_VALUES = setOf(
            "ir", "localhost",
            "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"
        )
    }
}
