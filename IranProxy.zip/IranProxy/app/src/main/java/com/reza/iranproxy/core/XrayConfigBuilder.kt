package com.reza.iranproxy.core

import com.reza.iranproxy.domain.model.Server
import com.reza.iranproxy.domain.model.ServerProtocol
import org.json.JSONArray
import org.json.JSONObject

object XrayConfigBuilder {

    fun build(server: Server): String {
        val config = JSONObject()

        config.put("log", buildLog())
        config.put("inbounds", buildInbounds())
        config.put("outbounds", buildOutbounds(server))
        config.put("routing", buildRouting(server))

        return config.toString(2)
    }

    // ── Log ──

    private fun buildLog(): JSONObject {
        return JSONObject().apply {
            put("loglevel", "warning")
            put("access", "none")
            put("error", "none")
        }
    }

    // ── Inbounds ──

    private fun buildInbounds(): JSONArray {
        val inbound = JSONObject().apply {
            put("tag", "socks")
            put("port", 10808)
            put("listen", "127.0.0.1")
            put("protocol", "socks")
            put("settings", JSONObject().apply {
                put("auth", "noauth")
                put("udp", true)
            })
            put("sniffing", JSONObject().apply {
                put("enabled", true)
                put("destOverride", JSONArray().apply {
                    put("http")
                    put("tls")
                    put("quic")
                })
            })
        }

        val httpInbound = JSONObject().apply {
            put("tag", "http")
            put("port", 10809)
            put("listen", "127.0.0.1")
            put("protocol", "http")
            put("settings", JSONObject())
        }

        return JSONArray().apply {
            put(inbound)
            put(httpInbound)
        }
    }

    // ── Outbounds ──

    private fun buildOutbounds(server: Server): JSONArray {
        val proxyOutbound = when (server.protocol) {
            ServerProtocol.VMESS -> buildVmessOutbound(server)
            ServerProtocol.VLESS -> buildVlessOutbound(server)
            ServerProtocol.SHADOWSOCKS -> buildShadowsocksOutbound(server)
            ServerProtocol.TROJAN -> buildTrojanOutbound(server)
            else -> buildVlessOutbound(server)
        }

        val directOutbound = JSONObject().apply {
            put("tag", "direct")
            put("protocol", "freedom")
            put("settings", JSONObject())
        }

        val blockOutbound = JSONObject().apply {
            put("tag", "block")
            put("protocol", "blackhole")
            put("settings", JSONObject().apply {
                put("response", JSONObject().apply {
                    put("type", "http")
                })
            })
        }

        return JSONArray().apply {
            put(proxyOutbound)
            put(directOutbound)
            put(blockOutbound)
        }
    }

    // ── VMess ──

    private fun buildVmessOutbound(server: Server): JSONObject {
        val streamSettings = buildStreamSettings(server)

        return JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "vmess")
            put("settings", JSONObject().apply {
                put("vnext", JSONArray().apply {
                    put(JSONObject().apply {
                        put("address", server.address)
                        put("port", server.port)
                        put("users", JSONArray().apply {
                            put(JSONObject().apply {
                                put("id", server.uuid)
                                put("alterId", server.alterId)
                                put("security", server.security.ifEmpty { "auto" })
                            })
                        })
                    })
                })
            })
            put("streamSettings", streamSettings)
        }
    }

    // ── VLess ──

    private fun buildVlessOutbound(server: Server): JSONObject {
        val streamSettings = buildStreamSettings(server)

        return JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "vless")
            put("settings", JSONObject().apply {
                put("vnext", JSONArray().apply {
                    put(JSONObject().apply {
                        put("address", server.address)
                        put("port", server.port)
                        put("users", JSONArray().apply {
                            put(JSONObject().apply {
                                put("id", server.uuid)
                                put("encryption", "none")
                                if (server.flow.isNotEmpty()) {
                                    put("flow", server.flow)
                                }
                            })
                        })
                    })
                })
            })
            put("streamSettings", streamSettings)
        }
    }

    // ── Shadowsocks ──

    private fun buildShadowsocksOutbound(server: Server): JSONObject {
        return JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "shadowsocks")
            put("settings", JSONObject().apply {
                put("servers", JSONArray().apply {
                    put(JSONObject().apply {
                        put("address", server.address)
                        put("port", server.port)
                        put("method", server.security.ifEmpty { "aes-256-gcm" })
                        put("password", server.password)
                    })
                })
            })
        }
    }

    // ── Trojan ──

    private fun buildTrojanOutbound(server: Server): JSONObject {
        val streamSettings = buildStreamSettings(server)

        return JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "trojan")
            put("settings", JSONObject().apply {
                put("servers", JSONArray().apply {
                    put(JSONObject().apply {
                        put("address", server.address)
                        put("port", server.port)
                        put("password", server.password)
                        if (server.sni.isNotEmpty()) {
                            put("serverName", server.sni)
                        }
                    })
                })
            })
            put("streamSettings", streamSettings)
        }
    }

    // ── Stream Settings ──

    private fun buildStreamSettings(server: Server): JSONObject {
        val security = when (server.tls) {
            "tls" -> "tls"
            "reality" -> "reality"
            else -> "tcp"
        }

        return JSONObject().apply {
            put("network", server.network)
            put("security", security)

            // TCP
            if (server.network == "tcp") {
                if (server.headerType != "none") {
                    put("tcpSettings", JSONObject().apply {
                        put("header", JSONObject().apply {
                            put("type", server.headerType)
                            if (server.host.isNotEmpty()) {
                                put("request", JSONObject().apply {
                                    put("path", JSONArray().apply {
                                        put(server.path.ifEmpty { "/" })
                                    })
                                    put("headers", JSONObject().apply {
                                        put("Host", JSONArray().apply {
                                            put(server.host)
                                        })
                                    })
                                })
                            }
                        })
                    })
                }
            }

            // WebSocket
            if (server.network == "ws") {
                put("wsSettings", JSONObject().apply {
                    if (server.path.isNotEmpty()) {
                        put("path", server.path)
                    }
                    if (server.host.isNotEmpty()) {
                        put("headers", JSONObject().apply {
                            put("Host", server.host)
                        })
                    }
                })
            }

            // gRPC
            if (server.network == "grpc") {
                put("grpcSettings", JSONObject().apply {
                    put("serviceName", server.host)
                })
            }

            // TLS
            if (security == "tls") {
                put("tlsSettings", JSONObject().apply {
                    if (server.sni.isNotEmpty()) {
                        put("serverName", server.sni)
                    }
                    put("allowInsecure", false)
                    put("fingerprint", server.fingerprint)
                    if (server.alpn.isNotEmpty()) {
                        put("alpn", JSONArray().apply {
                            server.alpn.split(",").forEach { put(it.trim()) }
                        })
                    }
                })
            }

            // Reality
            if (security == "reality") {
                put("realitySettings", JSONObject().apply {
                    put("serverName", server.sni)
                    put("fingerprint", server.fingerprint)
                    put("publicKey", server.realityPublicKey)
                    put("shortId", server.realityShortId)
                })
            }
        }
    }

    // ── Routing ──

    private fun buildRouting(server: Server): JSONObject {
        val rules = JSONArray().apply {
            // بایپس ترافیک داخلی
            put(JSONObject().apply {
                put("type", "field")
                put("outboundTag", "direct")
                put("ip", JSONArray().apply {
                    put("geoip:private")
                })
            })

            // بایپس سایت‌های ایرانی
            put(JSONObject().apply {
                put("type", "field")
                put("outboundTag", "direct")
                put("domain", JSONArray().apply {
                    put("geosite:category-ir")
                })
            })

            // بقیه از پروکسی
            put(JSONObject().apply {
                put("type", "field")
                put("outboundTag", "proxy")
                put("port", "0-65535")
            })
        }

        return JSONObject().apply {
            put("domainStrategy", "AsIs")
            put("rules", rules)
        }
    }

    // ── Generate Full Config ──

    fun buildForCore(server: Server, assetsPath: String): String {
        val config = build(server)

        // اضافه کردن مسیر فایل‌های geoip و geosite
        return config
    }
}
