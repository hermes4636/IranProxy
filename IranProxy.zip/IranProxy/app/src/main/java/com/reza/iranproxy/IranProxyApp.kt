package com.reza.iranproxy

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class IranProxyApp : Application()
