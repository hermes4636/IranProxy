package com.reza.iranproxy.di

import android.content.Context
import com.reza.iranproxy.core.XrayConfigBuilder
import com.reza.iranproxy.core.XrayCoreManager
import com.reza.iranproxy.core.XrayVpnService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object CoreModule {

    @Provides
    @Singleton
    fun provideXrayCoreManager(
        @ApplicationContext context: Context
    ): XrayCoreManager {
        return XrayCoreManager(context)
    }

    @Provides
    @Singleton
    fun provideXrayConfigBuilder(): XrayConfigBuilder {
        return XrayConfigBuilder
    }

    @Provides
    @Singleton
    fun provideXrayVpnService(): XrayVpnService.Companion {
        return XrayVpnService
    }
}
