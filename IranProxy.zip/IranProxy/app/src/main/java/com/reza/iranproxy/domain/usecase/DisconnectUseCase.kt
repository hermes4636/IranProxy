package com.reza.iranproxy.domain.usecase

import com.reza.iranproxy.domain.model.ConnectionStatus

class DisconnectUseCase(
    private val connectUseCase: ConnectUseCase
) {

    suspend operator fun invoke(): Result<Unit> {
        val currentStatus = connectUseCase.status.value

        if (currentStatus.isDisconnected) {
            return Result.failure(IllegalStateException("از قبل قطع است"))
        }

        return try {
            // TODO: قطع واقعی اتصال
            // ۱. استاپ Xray Core
            // ۲. بستن VPN Tunnel
            // ۳. پاک کردن کانفیگ موقت

            connectUseCase.reset()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
