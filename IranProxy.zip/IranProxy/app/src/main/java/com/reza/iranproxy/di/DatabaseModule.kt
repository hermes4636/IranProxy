package com.reza.iranproxy.di

import android.content.Context
import com.reza.iranproxy.data.local.AppDatabase
import com.reza.iranproxy.data.local.dao.RoutingRuleDao
import com.reza.iranproxy.data.local.dao.ServerDao
import com.reza.iranproxy.data.local.dao.SubscriptionDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return AppDatabase.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideServerDao(database: AppDatabase): ServerDao {
        return database.serverDao()
    }

    @Provides
    @Singleton
    fun provideSubscriptionDao(database: AppDatabase): SubscriptionDao {
        return database.subscriptionDao()
    }

    @Provides
    @Singleton
    fun provideRoutingRuleDao(database: AppDatabase): RoutingRuleDao {
        return database.routingRuleDao()
    }
}
