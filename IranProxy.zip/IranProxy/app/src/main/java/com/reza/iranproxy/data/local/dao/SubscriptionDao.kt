package com.reza.iranproxy.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.reza.iranproxy.data.local.entity.SubscriptionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SubscriptionDao {

    // ── Insert ──

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subscription: SubscriptionEntity): Long

    // ── Update ──

    @Update
    suspend fun update(subscription: SubscriptionEntity)

    // ── Delete ──

    @Delete
    suspend fun delete(subscription: SubscriptionEntity)

    @Query("DELETE FROM subscriptions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM subscriptions")
    suspend fun deleteAll()

    // ── Get All ──

    @Query("SELECT * FROM subscriptions ORDER BY created_at DESC")
    fun getAll(): Flow<List<SubscriptionEntity>>

    @Query("SELECT * FROM subscriptions ORDER BY created_at DESC")
    suspend fun getAllOnce(): List<SubscriptionEntity>

    // ── Get By ID ──

    @Query("SELECT * FROM subscriptions WHERE id = :id")
    suspend fun getById(id: Long): SubscriptionEntity?

    @Query("SELECT * FROM subscriptions WHERE id = :id")
    fun getByIdFlow(id: Long): Flow<SubscriptionEntity?>

    // ── Get By URL ──

    @Query("SELECT * FROM subscriptions WHERE url = :url LIMIT 1")
    suspend fun getByUrl(url: String): SubscriptionEntity?

    // ── Enabled ──

    @Query("SELECT * FROM subscriptions WHERE is_enabled = 1 ORDER BY created_at DESC")
    fun getEnabled(): Flow<List<SubscriptionEntity>>

    @Query("SELECT * FROM subscriptions WHERE is_enabled = 1 ORDER BY created_at DESC")
    suspend fun getEnabledOnce(): List<SubscriptionEntity>

    // ── Last Updated ──

    @Query("UPDATE subscriptions SET last_updated = :timestamp WHERE id = :id")
    suspend fun updateLastUpdated(id: Long, timestamp: Long = System.currentTimeMillis())

    // ── Server Count ──

    @Query("UPDATE subscriptions SET server_count = :count WHERE id = :id")
    suspend fun updateServerCount(id: Long, count: Int)

    // ── Traffic ──

    @Query("UPDATE subscriptions SET traffic_used = :used, traffic_total = :total WHERE id = :id")
    suspend fun updateTraffic(id: Long, used: Long, total: Long)

    // ── Expiry ──

    @Query("UPDATE subscriptions SET expires_at = :expiresAt WHERE id = :id")
    suspend fun updateExpiry(id: Long, expiresAt: Long?)

    // ── Error ──

    @Query("UPDATE subscriptions SET error_message = :error, last_updated = :timestamp WHERE id = :id")
    suspend fun setError(id: Long, error: String, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE subscriptions SET error_message = NULL WHERE id = :id")
    suspend fun clearError(id: Long)

    // ── Toggle ──

    @Query("UPDATE subscriptions SET is_enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)

    @Query("UPDATE subscriptions SET auto_update = :auto WHERE id = :id")
    suspend fun setAutoUpdate(id: Long, auto: Boolean)

    // ── Need Update ──

    @Query(
        """
        SELECT * FROM subscriptions
        WHERE auto_update = 1
          AND is_enabled = 1
          AND last_updated < :beforeTimestamp
        """
    )
    suspend fun getNeedUpdate(beforeTimestamp: Long): List<SubscriptionEntity>

    // ── Expired ──

    @Query(
        """
        SELECT * FROM subscriptions
        WHERE expires_at IS NOT NULL
          AND expires_at < :now
          AND is_enabled = 1
        """
    )
    suspend fun getExpired(now: Long = System.currentTimeMillis()): List<SubscriptionEntity>

    // ── Count ──

    @Query("SELECT COUNT(*) FROM subscriptions")
    fun getCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM subscriptions")
    suspend fun getCountOnce(): Int
}
