package com.reza.iranproxy.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.reza.iranproxy.data.local.entity.RoutingRuleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RoutingRuleDao {

    // ── Insert ──

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(rule: RoutingRuleEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rules: List<RoutingRuleEntity>): List<Long>

    // ── Update ──

    @Update
    suspend fun update(rule: RoutingRuleEntity)

    // ── Delete ──

    @Delete
    suspend fun delete(rule: RoutingRuleEntity)

    @Query("DELETE FROM routing_rules WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM routing_rules")
    suspend fun deleteAll()

    // ── Get All ──

    @Query("SELECT * FROM routing_rules ORDER BY priority DESC, name ASC")
    fun getAll(): Flow<List<RoutingRuleEntity>>

    @Query("SELECT * FROM routing_rules ORDER BY priority DESC, name ASC")
    suspend fun getAllOnce(): List<RoutingRuleEntity>

    // ── Get By ID ──

    @Query("SELECT * FROM routing_rules WHERE id = :id")
    suspend fun getById(id: Long): RoutingRuleEntity?

    @Query("SELECT * FROM routing_rules WHERE id = :id")
    fun getByIdFlow(id: Long): Flow<RoutingRuleEntity?>

    // ── Enabled ──

    @Query("SELECT * FROM routing_rules WHERE is_enabled = 1 ORDER BY priority DESC")
    fun getEnabled(): Flow<List<RoutingRuleEntity>>

    @Query("SELECT * FROM routing_rules WHERE is_enabled = 1 ORDER BY priority DESC")
    suspend fun getEnabledOnce(): List<RoutingRuleEntity>

    // ── By Outbound ──

    @Query("SELECT * FROM routing_rules WHERE outbound = :outbound AND is_enabled = 1 ORDER BY priority DESC")
    fun getByOutbound(outbound: String): Flow<List<RoutingRuleEntity>>

    @Query("SELECT * FROM routing_rules WHERE outbound = :outbound AND is_enabled = 1 ORDER BY priority DESC")
    suspend fun getByOutboundOnce(outbound: String): List<RoutingRuleEntity>

    // ── By Type ──

    @Query("SELECT * FROM routing_rules WHERE type = :type AND is_enabled = 1 ORDER BY priority DESC")
    fun getByType(type: String): Flow<List<RoutingRuleEntity>>

    // ── Toggle ──

    @Query("UPDATE routing_rules SET is_enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)

    @Query("UPDATE routing_rules SET priority = :priority WHERE id = :id")
    suspend fun setPriority(id: Long, priority: Int)

    @Query("UPDATE routing_rules SET outbound = :outbound WHERE id = :id")
    suspend fun setOutbound(id: Long, outbound: String)

    // ── Count ──

    @Query("SELECT COUNT(*) FROM routing_rules")
    fun getCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM routing_rules WHERE is_enabled = 1")
    suspend fun getEnabledCount(): Int

    @Query("SELECT COUNT(*) FROM routing_rules WHERE outbound = :outbound AND is_enabled = 1")
    suspend fun getCountByOutbound(outbound: String): Int
}
