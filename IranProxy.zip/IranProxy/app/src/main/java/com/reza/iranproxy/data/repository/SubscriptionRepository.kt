package com.reza.iranproxy.data.repository

import com.reza.iranproxy.data.local.dao.SubscriptionDao
import com.reza.iranproxy.data.local.entity.SubscriptionEntity
import kotlinx.coroutines.flow.Flow

class SubscriptionRepository(
    private val subscriptionDao: SubscriptionDao
) {

    // ── CRUD ──

    suspend fun insert(subscription: SubscriptionEntity): Long =
        subscriptionDao.insert(subscription)

    suspend fun update(subscription: SubscriptionEntity) =
        subscriptionDao.update(subscription)

    suspend fun delete(subscription: SubscriptionEntity) =
        subscriptionDao.delete(subscription)

    suspend fun deleteById(id: Long) =
        subscriptionDao.deleteById(id)

    suspend fun deleteAll() =
        subscriptionDao.deleteAll()

    // ── Get ──

    fun getAll(): Flow<List<SubscriptionEntity>> =
        subscriptionDao.getAll()

    suspend fun getAllOnce(): List<SubscriptionEntity> =
        subscriptionDao.getAllOnce()

    suspend fun getById(id: Long): SubscriptionEntity? =
        subscriptionDao.getById(id)

    fun getByIdFlow(id: Long): Flow<SubscriptionEntity?> =
        subscriptionDao.getByIdFlow(id)

    suspend fun getByUrl(url: String): SubscriptionEntity? =
        subscriptionDao.getByUrl(url)

    fun getEnabled(): Flow<List<SubscriptionEntity>> =
        subscriptionDao.getEnabled()

    suspend fun getEnabledOnce(): List<SubscriptionEntity> =
        subscriptionDao.getEnabledOnce()

    // ── Server Count ──

    suspend fun updateServerCount(id: Long, count: Int) =
        subscriptionDao.updateServerCount(id, count)

    // ── Traffic ──

    suspend fun updateTraffic(id: Long, used: Long, total: Long) =
        subscriptionDao.updateTraffic(id, used, total)

    // ── Expiry ──

    suspend fun updateExpiry(id: Long, expiresAt: Long?) =
        subscriptionDao.updateExpiry(id, expiresAt)

    // ── Last Updated ──

    suspend fun updateLastUpdated(id: Long) =
        subscriptionDao.updateLastUpdated(id)

    // ── Error ──

    suspend fun setError(id: Long, error: String) =
        subscriptionDao.setError(id, error)

    suspend fun clearError(id: Long) =
        subscriptionDao.clearError(id)

    // ── Toggle ──

    suspend fun setEnabled(id: Long, enabled: Boolean) =
        subscriptionDao.setEnabled(id, enabled)

    suspend fun setAutoUpdate(id: Long, auto: Boolean) =
        subscriptionDao.setAutoUpdate(id, auto)

    // ── Sync ──

    suspend fun getNeedUpdate(beforeTimestamp: Long): List<SubscriptionEntity> =
        subscriptionDao.getNeedUpdate(beforeTimestamp)

    suspend fun getExpired(): List<SubscriptionEntity> =
        subscriptionDao.getExpired()

    // ── Count ──

    fun getCount(): Flow<Int> =
        subscriptionDao.getCount()

    suspend fun getCountOnce(): Int =
        subscriptionDao.getCountOnce()
}
