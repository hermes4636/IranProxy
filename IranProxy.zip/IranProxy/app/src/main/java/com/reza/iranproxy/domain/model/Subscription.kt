package com.reza.iranproxy.domain.model

data class Subscription(
    val id: Long = 0,
    val name: String,
    val url: String,
    val token: String = "",
    val userAgent: String = "",
    val serverCount: Int = 0,
    val autoUpdate: Boolean = true,
    val lastUpdated: Long = 0L,
    val expiresAt: Long? = null,
    val trafficUsed: Long = 0L,
    val trafficTotal: Long = 0L,
    val isEnabled: Boolean = true,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isExpired: Boolean
        get() = expiresAt?.let { it < System.currentTimeMillis() } ?: false

    val daysUntilExpiry: Int?
        get() {
            if (expiresAt == null) return null
            val diff = expiresAt - System.currentTimeMillis()
            return (diff / (1000 * 60 * 60 * 24)).toInt()
        }

    val trafficDisplay: String
        get() {
            if (trafficTotal == 0L) return formatBytes(trafficUsed)
            return "${formatBytes(trafficUsed)} / ${formatBytes(trafficTotal)}"
        }

    val lastUpdatedDisplay: String
        get() {
            if (lastUpdated == 0L) return "هرگز"
            val diff = System.currentTimeMillis() - lastUpdated
            return when {
                diff < 60_000 -> "همین الان"
                diff < 3_600_000 -> "${diff / 60_000} دقیقه پیش"
                diff < 86_400_000 -> "${diff / 3_600_000} ساعت پیش"
                else -> "${diff / 86_400_000} روز پیش"
            }
        }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        if (bytes < 1024 * 1024) return "${bytes / 1024} KB"
        if (bytes < 1024 * 1024 * 1024) return "${bytes / (1024 * 1024)} MB"
        return "${bytes / (1024 * 1024 * 1024)} GB"
    }
}
