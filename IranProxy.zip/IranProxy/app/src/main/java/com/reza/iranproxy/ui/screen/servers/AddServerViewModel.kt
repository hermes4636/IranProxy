package com.reza.iranproxy.ui.screen.servers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reza.iranproxy.domain.model.Server
import com.reza.iranproxy.domain.model.ServerProtocol
import com.reza.iranproxy.domain.usecase.ImportServerUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddServerViewModel @Inject constructor(
    private val importServerUseCase: ImportServerUseCase
) : ViewModel() {

    // ── Form State ──

    private val _name = MutableStateFlow("")
    val name: StateFlow<String> = _name.asStateFlow()

    private val _address = MutableStateFlow("")
    val address: StateFlow<String> = _address.asStateFlow()

    private val _port = MutableStateFlow("")
    val port: StateFlow<String> = _port.asStateFlow()

    private val _protocol = MutableStateFlow(ServerProtocol.VMESS)
    val protocol: StateFlow<ServerProtocol> = _protocol.asStateFlow()

    private val _uuid = MutableStateFlow("")
    val uuid: StateFlow<String> = _uuid.asStateFlow()

    private val _alterId = MutableStateFlow("0")
    val alterId: StateFlow<String> = _alterId.asStateFlow()

    private val _password = MutableStateFlow("")
    val password: StateFlow<String> = _password.asStateFlow()

    private val _security = MutableStateFlow("auto")
    val security: StateFlow<String> = _security.asStateFlow()

    private val _network = MutableStateFlow("tcp")
    val network: StateFlow<String> = _network.asStateFlow()

    private val _headerType = MutableStateFlow("none")
    val headerType: StateFlow<String> = _headerType.asStateFlow()

    private val _host = MutableStateFlow("")
    val host: StateFlow<String> = _host.asStateFlow()

    private val _path = MutableStateFlow("")
    val path: StateFlow<String> = _path.asStateFlow()

    private val _tls = MutableStateFlow("none")
    val tls: StateFlow<String> = _tls.asStateFlow()

    private val _sni = MutableStateFlow("")
    val sni: StateFlow<String> = _sni.asStateFlow()

    private val _fingerprint = MutableStateFlow("chrome")
    val fingerprint: StateFlow<String> = _fingerprint.asStateFlow()

    private val _alpn = MutableStateFlow("")
    val alpn: StateFlow<String> = _alpn.asStateFlow()

    private val _flow = MutableStateFlow("")
    val flow: StateFlow<String> = _flow.asStateFlow()

    private val _realityPublicKey = MutableStateFlow("")
    val realityPublicKey: StateFlow<String> = _realityPublicKey.asStateFlow()

    private val _realityShortId = MutableStateFlow("")
    val realityShortId: StateFlow<String> = _realityShortId.asStateFlow()

    // ── UI State ──

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _saveResult = MutableStateFlow<SaveResult>(SaveResult.Idle)
    val saveResult: StateFlow<SaveResult> = _saveResult.asStateFlow()

    // ── Events ──

    fun updateName(value: String) { _name.value = value }
    fun updateAddress(value: String) { _address.value = value }
    fun updatePort(value: String) { _port.value = value }
    fun updateProtocol(value: ServerProtocol) { _protocol.value = value }
    fun updateUuid(value: String) { _uuid.value = value }
    fun updateAlterId(value: String) { _alterId.value = value }
    fun updatePassword(value: String) { _password.value = value }
    fun updateSecurity(value: String) { _security.value = value }
    fun updateNetwork(value: String) { _network.value = value }
    fun updateHeaderType(value: String) { _headerType.value = value }
    fun updateHost(value: String) { _host.value = value }
    fun updatePath(value: String) { _path.value = value }
    fun updateTls(value: String) { _tls.value = value }
    fun updateSni(value: String) { _sni.value = value }
    fun updateFingerprint(value: String) { _fingerprint.value = value }
    fun updateAlpn(value: String) { _alpn.value = value }
    fun updateFlow(value: String) { _flow.value = value }
    fun updateRealityPublicKey(value: String) { _realityPublicKey.value = value }
    fun updateRealityShortId(value: String) { _realityShortId.value = value }

    // ── Save ──

    fun save() {
        viewModelScope.launch {
            _isSaving.value = true
            _saveResult.value = SaveResult.Idle

            val portInt = _port.value.toIntOrNull()
            if (portInt == null) {
                _saveResult.value = SaveResult.Error("پورت نامعتبر است")
                _isSaving.value = false
                return@launch
            }

            importServerUseCase.fromManualInput(
                name = _name.value,
                address = _address.value,
                port = portInt,
                protocol = _protocol.value,
                uuid = _uuid.value,
                alterId = _alterId.value.toIntOrNull() ?: 0,
                password = _password.value,
                security = _security.value,
                network = _network.value,
                tls = _tls.value,
                sni = _sni.value,
                fingerprint = _fingerprint.value,
                alpn = _alpn.value,
                flow = _flow.value,
                realityPublicKey = _realityPublicKey.value,
                realityShortId = _realityShortId.value
            ).onSuccess { server ->
                _saveResult.value = SaveResult.Success(server)
            }.onFailure { error ->
                _saveResult.value = SaveResult.Error(error.message ?: "خطا در ذخیره")
            }

            _isSaving.value = false
        }
    }

    // ── Validate ──

    fun isFormValid(): Boolean {
        return _name.value.isNotBlank() &&
                _address.value.isNotBlank() &&
                _port.value.toIntOrNull() != null &&
                isProtocolFieldsValid()
    }

    private fun isProtocolFieldsValid(): Boolean {
        return when (_protocol.value) {
            ServerProtocol.VMESS, ServerProtocol.VLESS -> _uuid.value.isNotBlank()
            ServerProtocol.SHADOWSOCKS, ServerProtocol.TROJAN -> _password.value.isNotBlank()
            else -> true
        }
    }

    // ── Reset ──

    fun resetForm() {
        _name.value = ""
        _address.value = ""
        _port.value = ""
        _protocol.value = ServerProtocol.VMESS
        _uuid.value = ""
        _alterId.value = "0"
        _password.value = ""
        _security.value = "auto"
        _network.value = "tcp"
        _headerType.value = "none"
        _host.value = ""
        _path.value = ""
        _tls.value = "none"
        _sni.value = ""
        _fingerprint.value = "chrome"
        _alpn.value = ""
        _flow.value = ""
        _realityPublicKey.value = ""
        _realityShortId.value = ""
        _saveResult.value = SaveResult.Idle
    }

    // ── Sealed Class ──

    sealed class SaveResult {
        data object Idle : SaveResult()
        data class Success(val server: Server) : SaveResult()
        data class Error(val message: String) : SaveResult()
    }
}
