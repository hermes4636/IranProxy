package com.reza.iranproxy.ui.screen.servers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reza.iranproxy.data.repository.ServerRepository
import com.reza.iranproxy.domain.model.Server
import com.reza.iranproxy.domain.model.ServerProtocol
import com.reza.iranproxy.domain.usecase.SwitchServerUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ServerListViewModel @Inject constructor(
    private val serverRepository: ServerRepository,
    private val switchServerUseCase: SwitchServerUseCase
) : ViewModel() {

    // ── Servers ──

    val servers: StateFlow<List<Server>> = serverRepository.getAllServers()
        .mapToServers()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // ── Search ──

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredServers: StateFlow<List<Server>> = servers

    // ── Filter ──

    private val _selectedProtocol = MutableStateFlow<ServerProtocol?>(null)
    val selectedProtocol: StateFlow<ServerProtocol?> = _selectedProtocol.asStateFlow()

    // ── Sort ──

    private val _sortBy = MutableStateFlow(SortBy.NAME)
    val sortBy: StateFlow<SortBy> = _sortBy.asStateFlow()

    // ── Selection ──

    private val _selectedServerId = MutableStateFlow<Long?>(null)
    val selectedServerId: StateFlow<Long?> = _selectedServerId.asStateFlow()

    // ── Actions ──

    fun selectServer(server: Server) {
        viewModelScope.launch {
            switchServerUseCase(server)
            _selectedServerId.value = server.id
        }
    }

    fun deleteServer(server: Server) {
        viewModelScope.launch {
            serverRepository.delete(server)
        }
    }

    fun toggleFavorite(server: Server) {
        viewModelScope.launch {
            serverRepository.setFavorite(server.id, !server.isFavorite)
        }
    }

    fun testLatency(server: Server) {
        viewModelScope.launch {
            val fakeLatency = (50..500).random().toLong()
            serverRepository.updateLatency(server.id, fakeLatency)
        }
    }

    fun testAllLatencies() {
        viewModelScope.launch {
            val allServers = serverRepository.getAllServersOnce()
            allServers.forEach { server ->
                val fakeLatency = (50..500).random().toLong()
                serverRepository.updateLatency(server.id, fakeLatency)
            }
        }
    }

    fun updateSearch(query: String) {
        _searchQuery.value = query
    }

    fun selectProtocol(protocol: ServerProtocol?) {
        _selectedProtocol.value = protocol
    }

    fun selectSort(sort: SortBy) {
        _sortBy.value = sort
    }

    fun clearSelection() {
        _selectedServerId.value = null
    }

    // ── Enums ──

    enum class SortBy {
        NAME, LATENCY, PROTOCOL
    }

    // ── Mapper ──

    private fun kotlinx.coroutines.flow.Flow<List<com.reza.iranproxy.data.local.entity.ServerEntity>>.mapToServers():
            kotlinx.coroutines.flow.Flow<List<Server>> {
        return kotlinx.coroutines.flow.map(this) { entities ->
            entities.map { it.toDomain() }
        }
    }

    private fun com.reza.iranproxy.data.local.entity.ServerEntity.toDomain(): Server {
        return Server(
            id = id,
            name = name,
            address = address,
            port = port,
            protocol = ServerProtocol.fromString(protocol),
            uuid = uuid,
            alterId = alterId,
            password = password,
            security = security,
            network = network,
            headerType = headerType,
            host = host,
            path = path,
            tls = tls,
            sni = sni,
            fingerprint = fingerprint,
            alpn = alpn,
            flow = flow,
            realityPublicKey = realityPublicKey,
            realityShortId = realityShortId,
            subscriptionId = subscriptionId,
            isActive = isActive,
            isFavorite = isFavorite,
            latency = latency,
            trafficUsed = trafficUsed,
            trafficTotal = trafficTotal,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }
}
