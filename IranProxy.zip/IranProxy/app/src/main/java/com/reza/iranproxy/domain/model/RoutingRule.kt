package com.reza.iranproxy.domain.model

data class RoutingRule(
    val id: Long = 0,
    val name: String,
    val type: String,
    val value: String,
    val outbound: String = "direct",
    val isEnabled: Boolean = true,
    val priority: Int = 0,
    val removeFromDirect: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val outboundDisplayName: String
        get() = when (outbound) {
            "proxy" -> "پروکسی"
            "direct" -> "مستقیم"
            "block" -> "مسدود"
            "dns" -> "DNS"
            else -> outbound
        }

    val typeDisplayName: String
        get() = when (type) {
            "DOMAIN" -> "دامنه"
            "DOMAIN-SUFFIX" -> "پسوند دامنه"
            "DOMAIN-KEYWORD" -> "کلمه کلیدی دامنه"
            "IP-CIDR" -> "آدرس IP"
            "IP-CIDR6" -> "آدرس IPv6"
            "GEOIP" -> "موقعیت جغرافیایی"
            "GEOSITE" -> "سایت جغرافیایی"
            "PROCESS-NAME" -> "نام پروسه"
            "PROCESS-PATH" -> "مسیر پروسه"
            else -> type
        }

    companion object {
        val OUTBOUND_PROXY = "proxy"
        val OUTBOUND_DIRECT = "direct"
        val OUTBOUND_BLOCK = "block"
        val OUTBOUND_DNS = "dns"
    }
}
