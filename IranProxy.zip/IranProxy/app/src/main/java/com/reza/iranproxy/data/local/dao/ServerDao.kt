package com.reza.iranproxy.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.reza.iranproxy.data.local.entity.ServerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ServerDao {

    // ── Insert ──

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(server: ServerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(servers: List<ServerEntity>): List<Long>

    // ── Update ──

    @Update
    suspend fun update(server: ServerEntity)

    // ── Delete ──

    @Delete
    suspend fun delete(server: ServerEntity)

    @Query("DELETE FROM servers WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM servers WHERE subscription_id = :subscriptionId")
    suspend fun deleteBySubscriptionId(subscriptionId: Long)

    @Query("DELETE FROM servers")
    suspend fun deleteAll()

    // ── Get All ──

    @Query("SELECT * FROM servers ORDER BY is_active DESC, name ASC")
    fun getAllServers(): Flow<List<ServerEntity>>

    @Query("SELECT * FROM servers ORDER BY is_active DESC, name ASC")
    suspend fun getAllServersOnce(): List<ServerEntity>

    // ── Get By ID ──

    @Query("SELECT * FROM servers WHERE id = :id")
    suspend fun getById(id: Long): ServerEntity?

    @Query("SELECT * FROM servers WHERE id = :id")
    fun getByIdFlow(id: Long): Flow<ServerEntity?>

    // ── Active Server ──

    @Query("SELECT * FROM servers WHERE is_active = 1 LIMIT 1")
    fun getActiveServer(): Flow<ServerEntity?>

    @Query("SELECT * FROM servers WHERE is_active = 1 LIMIT 1")
    suspend fun getActiveServerOnce(): ServerEntity?

    // ── Get By Subscription ──

    @Query("SELECT * FROM servers WHERE subscription_id = :subscriptionId ORDER BY name ASC")
    fun getBySubscriptionId(subscriptionId: Long): Flow<List<ServerEntity>>

    // ── Get By Protocol ──

    @Query("SELECT * FROM servers WHERE protocol = :protocol ORDER BY name ASC")
    fun getByProtocol(protocol: String): Flow<List<ServerEntity>>

    // ── Favorites ──

    @Query("SELECT * FROM servers WHERE is_favorite = 1 ORDER BY name ASC")
    fun getFavorites(): Flow<List<ServerEntity>>

    @Query("UPDATE servers SET is_favorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: Long, isFavorite: Boolean)

    // ── Search ──

    @Query(
        """
        SELECT * FROM servers
        WHERE name LIKE '%' || :query || '%'
           OR address LIKE '%' || :query || '%'
        ORDER BY name ASC
        """
    )
    fun search(query: String): Flow<List<ServerEntity>>

    // ── Active Switch ──

    @Query("UPDATE servers SET is_active = 0")
    suspend fun deactivateAll()

    @Query("UPDATE servers SET is_active = 1 WHERE id = :id")
    suspend fun setActive(id: Long)

    @Query("UPDATE servers SET is_active = 0 WHERE id = :id")
    suspend fun setInactive(id: Long)

    // ── Latency ──

    @Query("UPDATE servers SET latency = :latency, updated_at = :timestamp WHERE id = :id")
    suspend fun updateLatency(id: Long, latency: Long, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE servers SET latency = -1")
    suspend fun resetAllLatencies()

    @Query(
        """
        SELECT * FROM servers
        WHERE latency > 0
        ORDER BY latency ASC
        LIMIT :limit
        """
    )
    fun getBestByLatency(limit: Int = 5): Flow<List<ServerEntity>>

    // ── Traffic ──

    @Query("UPDATE servers SET traffic_used = :used, traffic_total = :total WHERE id = :id")
    suspend fun updateTraffic(id: Long, used: Long, total: Long)

    // ── Count ──

    @Query("SELECT COUNT(*) FROM servers")
    fun getCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM servers")
    suspend fun getCountOnce(): Int

    @Query("SELECT COUNT(*) FROM servers WHERE subscription_id = :subscriptionId")
    suspend fun getCountBySubscription(subscriptionId: Long): Int

    // ── Filter ──

    @Query(
        """
        SELECT * FROM servers
        WHERE (:protocol IS NULL OR protocol = :protocol)
          AND (:tls IS NULL OR tls = :tls)
          AND (:network IS NULL OR network = :network)
        ORDER BY name ASC
        """
    )
    fun getFiltered(
        protocol: String? = null,
        tls: String? = null,
        network: String? = null
    ): Flow<List<ServerEntity>>

    @Query(
        """
        SELECT * FROM servers
        WHERE (:protocol IS NULL OR protocol = :protocol)
          AND (:tls IS NULL OR tls = :tls)
          AND (:network IS NULL OR network = :network)
        ORDER BY name ASC
        """
    )
    suspend fun getFilteredOnce(
        protocol: String? = null,
        tls: String? = null,
        network: String? = null
    ): List<ServerEntity>
}
