package com.reza.iranproxy.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = Blue500,
    onPrimary = White,
    primaryContainer = Blue700,
    onPrimaryContainer = Blue200,

    secondary = Teal200,
    onSecondary = DarkBackground,
    secondaryContainer = Teal700,
    onSecondaryContainer = Teal200,

    background = DarkBackground,
    onBackground = Gray100,

    surface = DarkSurface,
    onSurface = Gray100,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Gray300,

    error = Red500,
    onError = White,
    errorContainer = Red700,
    onErrorContainer = White
)

private val LightColorScheme = lightColorScheme(
    primary = Blue700,
    onPrimary = White,
    primaryContainer = Blue200,
    onPrimaryContainer = Blue700,

    secondary = Teal700,
    onSecondary = White,
    secondaryContainer = Teal200,
    onSecondaryContainer = Teal700,

    background = Gray100,
    onBackground = DarkBackground,

    surface = White,
    onSurface = DarkBackground,
    surfaceVariant = Gray300,
    onSurfaceVariant = Gray700,

    error = Red700,
    onError = White,
    errorContainer = Red500,
    onErrorContainer = White
)

@Composable
fun IranProxyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
