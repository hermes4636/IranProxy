package com.reza.iranproxy.ui.screen.subscriptions

import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reza.iranproxy.data.local.entity.ServerEntity
import com.reza.iranproxy.data.local.entity.SubscriptionEntity
import com.reza.iranproxy.data.repository.ServerRepository
import com.reza.iranproxy.data.repository.SubscriptionRepository
import com.reza.iranproxy.domain.model.Subscription
import com.reza.iranproxy.domain.model.ServerProtocol
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import javax.inject.Inject

@HiltViewModel
class SubscriptionViewModel @Inject constructor(
    private val subscriptionRepository: SubscriptionRepository,
    private val serverRepository: ServerRepository
) : ViewModel() {

    // ── لیست اشتراک‌ها ──

    val subscriptions: StateFlow<List<Subscription>> = subscriptionRepository.getAll()
        .map { entities -> entities.map { it.toDomain() } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    // ── دیالوگ افزودن ──

    private val _showAddDialog = MutableStateFlow(false)
    val showAddDialog: StateFlow<Boolean> = _showAddDialog.asStateFlow()

    private val _newSubName = MutableStateFlow("")
    val newSubName: StateFlow<String> = _newSubName.asStateFlow()

    private val _newSubUrl = MutableStateFlow("")
    val newSubUrl: StateFlow<String> = _newSubUrl.asStateFlow()

    // ── وضعیت بارگذاری ──

    private val _updatingId = MutableStateFlow<Long?>(null)
    val updatingId: StateFlow<Long?> = _updatingId.asStateFlow()

    private val _isRefreshingAll = MutableStateFlow(false)
    val isRefreshingAll: StateFlow<Boolean> = _isRefreshingAll.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // ══════════════════════════════════════════
    //  عملیات
    // ══════════════════════════════════════════

    // ── نمایش/مخفی کردن دیالوگ ──

    fun showAddDialog() {
        _showAddDialog.value = true
        _newSubName.value = ""
        _newSubUrl.value = ""
    }

    fun hideAddDialog() {
        _showAddDialog.value = false
    }

    fun updateNewSubName(value: String) {
        _newSubName.value = value
    }

    fun updateNewSubUrl(value: String) {
        _newSubUrl.value = value
    }

    fun isAddFormValid(): Boolean =
        _newSubName.value.trim().isNotBlank() &&
                _newSubUrl.value.trim().isNotBlank()

    // ── افزودن اشتراک ──

    fun addSubscription() {
        val name = _newSubName.value.trim()
        val url = _newSubUrl.value.trim()

        if (name.isBlank() || url.isBlank()) {
            _errorMessage.value = "نام و لینک نمی‌تواند خالی باشد"
            return
        }

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            _errorMessage.value = "لینک باید با http:// یا https:// شروع شود"
            return
        }

        viewModelScope.launch {
            // بررسی تکراری
            val existing = subscriptionRepository.getByUrl(url)
            if (existing != null) {
                _errorMessage.value = "این لینک قبلاً اضافه شده"
                return@launch
            }

            val id = subscriptionRepository.insert(
                SubscriptionEntity(name = name, url = url)
            )

            _showAddDialog.value = false
            _newSubName.value = ""
            _newSubUrl.value = ""
            _errorMessage.value = null

            // بروزرسانی فوری بعد از اضافه کردن
            updateSubscription(id)
        }
    }

    // ── حذف اشتراک ──

    fun deleteSubscription(subscription: Subscription) {
        viewModelScope.launch {
            // حذف سرورهای مرتبط
            serverRepository.deleteBySubscriptionId(subscription.id)
            // حذف اشتراک
            subscriptionRepository.deleteById(subscription.id)
        }
    }

    // ── بروزرسانی یک اشتراک ──

    fun updateSubscription(subscriptionId: Long) {
        viewModelScope.launch {
            _updatingId.value = subscriptionId
            _errorMessage.value = null

            try {
                val sub = subscriptionRepository.getById(subscriptionId)
                if (sub == null) {
                    _errorMessage.value = "اشتراک یافت نشد"
                    _updatingId.value = null
                    return@launch
                }

                // ۱. دریافت محتوا از لینک
                val rawContent = fetchSubscriptionContent(sub.url, sub.userAgent)

                // ۲. پارس و تبدیل به لیست سرور
                val servers = parseSubscriptionContent(rawContent, subscriptionId)

                // ۳. حذف سرورهای قدیمی این اشتراک
                serverRepository.deleteBySubscriptionId(subscriptionId)

                // ۴. ذخیره سرورهای جدید
                if (servers.isNotEmpty()) {
                    serverRepository.insertAll(servers)
                }

                // ۵. آپدیت اطلاعات اشتراک
                val updatedSub = sub.copy(
                    serverCount = servers.size,
                    lastUpdated = System.currentTimeMillis(),
                    errorMessage = null
                )
                subscriptionRepository.update(updatedSub.toEntity())

            } catch (e: Exception) {
                _errorMessage.value = "خطا در بروزرسانی: ${e.localizedMessage ?: "ناشناخته"}"
                subscriptionRepository.setError(
                    subscriptionId,
                    e.message ?: "خطای ناشناخته"
                )
            }

            _updatingId.value = null
        }
    }

    // ── بروزرسانی همه ──

    fun updateAllSubscriptions() {
        viewModelScope.launch {
            _isRefreshingAll.value = true

            val all = subscriptionRepository.getAllOnce()
            for (sub in all) {
                if (sub.isEnabled) {
                    updateSubscription(sub.id)
                }
            }

            _isRefreshingAll.value = false
        }
    }

    // ── تغییر وضعیت فعال/غیرفعال ──

    fun toggleEnabled(subscription: Subscription) {
        viewModelScope.launch {
            subscriptionRepository.setEnabled(subscription.id, !subscription.isEnabled)
        }
    }

    // ── تغییر وضعیت بروزرسانی خودکار ──

    fun toggleAutoUpdate(subscription: Subscription) {
        viewModelScope.launch {
            subscriptionRepository.setAutoUpdate(subscription.id, !subscription.autoUpdate)
        }
    }

    // ── پاک کردن خطا ──

    fun clearError() {
        _errorMessage.value = null
    }

    // ══════════════════════════════════════════
    //  HTTP + پارس
    // ══════════════════════════════════════════

    private suspend fun fetchSubscriptionContent(
        url: String,
        userAgent: String
    ): String = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.apply {
                connectTimeout = 15_000
                readTimeout = 15_000
                requestMethod = "GET"
                setRequestProperty(
                    "User-Agent",
                    userAgent.ifBlank { "IranProxy/1.0" }
                )
                connect()
            }

            if (conn.responseCode !in 200..299) {
                throw Exception("خطای سرور: ${conn.responseCode}")
            }

            val bytes = conn.inputStream.readBytes()
            val text = String(bytes, Charsets.UTF_8).trim()

            // اشتراک‌ها معمولاً base64-encoded هستند
            try {
                val decoded = String(Base64.decode(text, Base64.DEFAULT), Charsets.UTF_8).trim()
                // اگر بعد از دیکود خط vless/vmess/ss/trojan داشت، یعنی درست decode شده
                if (decoded.contains("://")) decoded else text
            } catch (_: Exception) {
                text
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun parseSubscriptionContent(
        content: String,
        subscriptionId: Long
    ): List<ServerEntity> {
        val lines = content.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }

        return lines.mapNotNull { line ->
            try {
                parseUriToServer(line, subscriptionId)
            } catch (_: Exception) {
                null // لینک‌های نامعتبر نادیده گرفته می‌شوند
            }
        }
    }

    private fun parseUriToServer(uri: String, subscriptionId: Long): ServerEntity? {
        return when {
            uri.startsWith("vmess://") -> parseVmess(uri, subscriptionId)
            uri.startsWith("vless://") -> parseVless(uri, subscriptionId)
            uri.startsWith("ss://")    -> parseShadowsocks(uri, subscriptionId)
            uri.startsWith("trojan://") -> parseTrojan(uri, subscriptionId)
            else -> null
        }
    }

    // ── VMess ──

    private fun parseVmess(uri: String, subscriptionId: Long): ServerEntity {
        val encoded = uri.removePrefix("vmess://")
        val json = String(Base64.decode(encoded, Base64.DEFAULT), Charsets.UTF_8)
        // پارس ساده JSON با regex — بدون وابستگی به Gson/Moshi
        fun String.field(key: String): String {
            val regex = Regex("\"$key\"\\s*:\\s*\"([^\"]*?)\"")
            return regex.find(this)?.groupValues?.get(1) ?: ""
        }
        return ServerEntity(
            name = json.field("ps").ifBlank { json.field("add") },
            address = json.field("add"),
            port = json.field("port").toIntOrNull() ?: 443,
            protocol = ServerProtocol.VMESS.value,
            uuid = json.field("id"),
            alterId = json.field("aid").toIntOrNull() ?: 0,
            security = json.field("scy").ifBlank { "auto" },
            network = json.field("net").ifBlank { "tcp" },
            headerType = json.field("type").ifBlank { "none" },
            host = json.field("host"),
            path = json.field("path"),
            tls = json.field("tls").ifBlank { "none" },
            sni = json.field("sni"),
            fingerprint = json.field("fp").ifBlank { "chrome" },
            alpn = json.field("alpn"),
            subscriptionId = subscriptionId
        )
    }

    // ── VLESS ──

    private fun parseVless(uri: String, subscriptionId: Long): ServerEntity {
        // vless://uuid@host:port?params#name
        val withoutScheme = uri.removePrefix("vless://")
        val namePart = withoutScheme.substringAfter("#", "").let {
            java.net.URLDecoder.decode(it, "UTF-8")
        }
        val withoutName = withoutScheme.substringBefore("#")
        val userInfo = withoutName.substringBefore("@")
        val hostPort = withoutName.substringAfter("@")
        val host = hostPort.substringBeforeLast(":")
        val port = hostPort.substringAfterLast(":").toIntOrNull() ?: 443
        val paramsRaw = uri.substringAfter("?", "").substringBefore("#")
        val params = parseQueryParams(paramsRaw)

        return ServerEntity(
            name = namePart.ifBlank { host },
            address = host,
            port = port,
            protocol = ServerProtocol.VLESS.value,
            uuid = userInfo,
            security = params["security"] ?: "none",
            network = params["type"] ?: "tcp",
            headerType = params["headerType"] ?: "none",
            host = params["host"] ?: "",
            path = params["path"] ?: "",
            tls = params["security"] ?: "none",
            sni = params["sni"] ?: "",
            fingerprint = params["fp"] ?: "chrome",
            alpn = params["alpn"] ?: "",
            flow = params["flow"] ?: "",
            realityPublicKey = params["pbk"] ?: "",
            realityShortId = params["sid"] ?: "",
            subscriptionId = subscriptionId
        )
    }

    // ── Shadowsocks ──

    private fun parseShadowsocks(uri: String, subscriptionId: Long): ServerEntity {
        // ss://base64(method:password)@host:port#name
        // یا ss://base64(method:password@host:port)#name
        val withoutScheme = uri.removePrefix("ss://")
        val name = java.net.URLDecoder.decode(
            withoutScheme.substringAfter("#", ""),
            "UTF-8"
        )
        val withoutName = withoutScheme.substringBefore("#")

        val userInfo: String
        val hostPort: String

        if (withoutName.contains("@")) {
            userInfo = withoutName.substringBefore("@")
            hostPort = withoutName.substringAfter("@")
        } else {
            val decoded = String(
                Base64.decode(withoutName, Base64.DEFAULT),
                Charsets.UTF_8
            )
            userInfo = decoded.substringBefore("@")
            hostPort = decoded.substringAfter("@")
        }

        val method = userInfo.substringBefore(":")
        val password = userInfo.substringAfter(":")
        val host = hostPort.substringBeforeLast(":")
        val port = hostPort.substringAfterLast(":").toIntOrNull() ?: 443

        return ServerEntity(
            name = name.ifBlank { host },
            address = host,
            port = port,
            protocol = ServerProtocol.SHADOWSOCKS.value,
            password = "$method:$password",
            subscriptionId = subscriptionId
        )
    }

    // ── Trojan ──

    private fun parseTrojan(uri: String, subscriptionId: Long): ServerEntity {
        // trojan://password@host:port?params#name
        val withoutScheme = uri.removePrefix("trojan://")
        val name = java.net.URLDecoder.decode(
            withoutScheme.substringAfter("#", ""),
            "UTF-8"
        )
        val withoutName = withoutScheme.substringBefore("#")
        val password = withoutName.substringBefore("@")
        val hostPort = withoutName.substringAfter("@")
        val host = hostPort.substringBeforeLast(":")
        val port = hostPort.substringAfterLast(":").toIntOrNull() ?: 443
        val paramsRaw = uri.substringAfter("?", "").substringBefore("#")
        val params = parseQueryParams(paramsRaw)

        return ServerEntity(
            name = name.ifBlank { host },
            address = host,
            port = port,
            protocol = ServerProtocol.TROJAN.value,
            password = password,
            sni = params["sni"] ?: host,
            fingerprint = params["fp"] ?: "chrome",
            alpn = params["alpn"] ?: "",
            network = params["type"] ?: "tcp",
            host = params["host"] ?: "",
            path = params["path"] ?: "",
            tls = "tls",
            subscriptionId = subscriptionId
        )
    }

    // ── ابزارها ──

    private fun parseQueryParams(query: String): Map<String, String> {
        if (query.isBlank()) return emptyMap()
        return query.split("&").associate { param ->
            val key = param.substringBefore("=")
            val value = java.net.URLDecoder.decode(
                param.substringAfter("="),
                "UTF-8"
            )
            key to value
        }
    }

    // ══════════════════════════════════════════
    //  Mapper: Entity ↔ Domain
    // ══════════════════════════════════════════

    private fun SubscriptionEntity.toDomain() = Subscription(
        id = id,
        name = name,
        url = url,
        token = token,
        userAgent = userAgent,
        serverCount = serverCount,
        autoUpdate = autoUpdate,
        lastUpdated = lastUpdated,
        expiresAt = expiresAt,
        trafficUsed = trafficUsed,
        trafficTotal = trafficTotal,
        isEnabled = isEnabled,
        errorMessage = errorMessage,
        createdAt = createdAt
    )

    private fun Subscription.toEntity() = SubscriptionEntity(
        id = id,
        name = name,
        url = url,
        token = token,
        userAgent = userAgent,
        serverCount = serverCount,
        autoUpdate = autoUpdate,
        lastUpdated = lastUpdated,
        expiresAt = expiresAt,
        trafficUsed = trafficUsed,
        trafficTotal = trafficTotal,
        isEnabled = isEnabled,
        errorMessage = errorMessage,
        createdAt = createdAt
    )
}
