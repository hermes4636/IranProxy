package com.reza.iranproxy.di

import android.content.Context
import com.reza.iranproxy.data.repository.RoutingRepository
import com.reza.iranproxy.data.repository.ServerRepository
import com.reza.iranproxy.data.repository.SubscriptionRepository
import com.reza.iranproxy.domain.usecase.ConnectUseCase
import com.reza.iranproxy.domain.usecase.DisconnectUseCase
import com.reza.iranproxy.domain.usecase.ImportServerUseCase
import com.reza.iranproxy.domain.usecase.SwitchServerUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    // ── Repositories ──

    @Provides
    @Singleton
    fun provideServerRepository(
        databaseModule: DatabaseModule
    ): ServerRepository {
        return ServerRepository(databaseModule.serverDao())
    }

    @Provides
    @Singleton
    fun provideSubscriptionRepository(
        databaseModule: DatabaseModule
    ): SubscriptionRepository {
        return SubscriptionRepository(databaseModule.subscriptionDao())
    }

    @Provides
    @Singleton
    fun provideRoutingRepository(
        databaseModule: DatabaseModule
    ): RoutingRepository {
        return RoutingRepository(databaseModule.routingRuleDao())
    }

    // ── UseCases ──

    @Provides
    @Singleton
    fun provideConnectUseCase(): ConnectUseCase {
        return ConnectUseCase()
    }

    @Provides
    @Singleton
    fun provideDisconnectUseCase(
        connectUseCase: ConnectUseCase
    ): DisconnectUseCase {
        return DisconnectUseCase(connectUseCase)
    }

    @Provides
    @Singleton
    fun provideSwitchServerUseCase(
        serverRepository: ServerRepository,
        connectUseCase: ConnectUseCase,
        disconnectUseCase: DisconnectUseCase
    ): SwitchServerUseCase {
        return SwitchServerUseCase(
            serverRepository,
            connectUseCase,
            disconnectUseCase
        )
    }

    @Provides
    @Singleton
    fun provideImportServerUseCase(
        serverRepository: ServerRepository
    ): ImportServerUseCase {
        return ImportServerUseCase(serverRepository)
    }
}
