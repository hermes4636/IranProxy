package com.reza.iranproxy.data.repository

import com.reza.iranproxy.data.local.dao.ServerDao
import com.reza.iranproxy.data.local.entity.ServerEntity
import kotlinx.coroutines.flow.Flow

class ServerRepository(
    private val serverDao: ServerDao
) {

    // ── CRUD ──

    suspend fun insert(server: ServerEntity): Long =
        serverDao.insert(server)

    suspend fun insertAll(servers: List<ServerEntity>): List<Long> =
        serverDao.insertAll(servers)

    suspend fun update(server: ServerEntity) =
        serverDao.update(server)

    suspend fun delete(server: ServerEntity) =
        serverDao.delete(server)

    suspend fun deleteById(id: Long) =
        serverDao.deleteById(id)

    suspend fun deleteBySubscriptionId(subscriptionId: Long) =
        serverDao.deleteBySubscriptionId(subscriptionId)

    suspend fun deleteAll() =
        serverDao.deleteAll()

    // ── Get ──

    fun getAllServers(): Flow<List<ServerEntity>> =
        serverDao.getAllServers()

    suspend fun getAllServersOnce(): List<ServerEntity> =
        serverDao.getAllServersOnce()

    suspend fun getById(id: Long): ServerEntity? =
        serverDao.getById(id)

    fun getByIdFlow(id: Long): Flow<ServerEntity?> =
        serverDao.getByIdFlow(id)

    fun getBySubscriptionId(subscriptionId: Long): Flow<List<ServerEntity>> =
        serverDao.getBySubscriptionId(subscriptionId)

    fun getByProtocol(protocol: String): Flow<List<ServerEntity>> =
        serverDao.getByProtocol(protocol)

    fun search(query: String): Flow<List<ServerEntity>> =
        serverDao.search(query)

    // ── Favorites ──

    fun getFavorites(): Flow<List<ServerEntity>> =
        serverDao.getFavorites()

    suspend fun setFavorite(id: Long, isFavorite: Boolean) =
        serverDao.setFavorite(id, isFavorite)

    // ── Active ──

    fun getActiveServer(): Flow<ServerEntity?> =
        serverDao.getActiveServer()

    suspend fun getActiveServerOnce(): ServerEntity? =
        serverDao.getActiveServerOnce()

    suspend fun switchToServer(serverId: Long) {
        serverDao.deactivateAll()
        serverDao.setActive(serverId)
    }

    suspend fun disconnect() {
        serverDao.deactivateAll()
    }

    // ── Latency ──

    fun getBestByLatency(limit: Int = 5): Flow<List<ServerEntity>> =
        serverDao.getBestByLatency(limit)

    suspend fun updateLatency(id: Long, latency: Long) =
        serverDao.updateLatency(id, latency)

    suspend fun resetAllLatencies() =
        serverDao.resetAllLatencies()

    // ── Traffic ──

    suspend fun updateTraffic(id: Long, used: Long, total: Long) =
        serverDao.updateTraffic(id, used, total)

    // ── Filter ──

    fun getFiltered(
        protocol: String? = null,
        tls: String? = null,
        network: String? = null
    ): Flow<List<ServerEntity>> =
        serverDao.getFiltered(protocol, tls, network)

    // ── Count ──

    fun getCount(): Flow<Int> =
        serverDao.getCount()

    suspend fun getCountOnce(): Int =
        serverDao.getCountOnce()

    suspend fun getCountBySubscription(subscriptionId: Long): Int =
        serverDao.getCountBySubscription(subscriptionId)
}
