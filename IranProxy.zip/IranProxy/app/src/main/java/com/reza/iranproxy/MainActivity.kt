package com.reza.iranproxy

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.reza.iranproxy.core.XrayVpnService
import com.reza.iranproxy.ui.navigation.AppNavigation
import com.reza.iranproxy.ui.theme.IranProxyTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    // ── دریافت مجوز VPN ──

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            // مجوز VPN تأیید شد — شروع سرویس
            XrayVpnService.start(this)
            Toast.makeText(this, "VPN فعال شد", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "دسترسی VPN رد شد", Toast.LENGTH_SHORT).show()
        }
    }

    // ── دریافت مجوز اعلان (Android 13+) ──

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(this, "بدون مجوز اعلان، وضعیت VPN نمایش داده نمی‌شود", Toast.LENGTH_SHORT).show()
        }
    }

    // ══════════════════════════════════════════
    //  Lifecycle
    // ══════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // درخواست مجوز اعلان
        requestNotificationPermission()

        setContent {
            IranProxyTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    AppNavigation(navController = navController)
                }
            }
        }
    }

    // ══════════════════════════════════════════
    //  VPN Permission
    // ══════════════════════════════════════════

    /**
     * فراخوانی از هرجای اپ برای درخواست مجوز VPN.
     * قابل استفاده از HomeViewModel یا هر ViewModel دیگر.
     */
    fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        } else {
            // مجوز قبلاً داده شده
            XrayVpnService.start(this)
            Toast.makeText(this, "VPN فعال شد", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * قطع VPN از هرجای اپ.
     */
    fun stopVpn() {
        XrayVpnService.stop(this)
    }

    // ══════════════════════════════════════════
    //  Notification Permission
    // ══════════════════════════════════════════

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(
                android.Manifest.permission.POST_NOTIFICATIONS
            )
        }
    }
}
