package com.reza.iranproxy.ui.screen.subscriptions

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.reza.iranproxy.domain.model.Subscription
import com.reza.iranproxy.ui.theme.Gray500
import com.reza.iranproxy.ui.theme.Green500
import com.reza.iranproxy.ui.theme.Orange500
import com.reza.iranproxy.ui.theme.Red500

// ══════════════════════════════════════════════════════════════
//  صفحه اشتراک‌ها
// ══════════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    onNavigateBack: () -> Unit = {},
    viewModel: SubscriptionViewModel = hiltViewModel()
) {
    val subscriptions by viewModel.subscriptions.collectAsState()
    val showAddDialog by viewModel.showAddDialog.collectAsState()
    val updatingId by viewModel.updatingId.collectAsState()
    val isRefreshingAll by viewModel.isRefreshingAll.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val newSubName by viewModel.newSubName.collectAsState()
    val newSubUrl by viewModel.newSubUrl.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var showDeleteDialog by remember { mutableStateOf<Subscription?>(null) }

    // نمایش خطا در Snackbar
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("اشتراک‌ها") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت"
                        )
                    }
                },
                actions = {
                    // دکمه بروزرسانی همه
                    if (subscriptions.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.updateAllSubscriptions() },
                            enabled = !isRefreshingAll
                        ) {
                            if (isRefreshingAll) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Update,
                                    contentDescription = "بروزرسانی همه",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.showAddDialog() },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "افزودن اشتراک")
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (subscriptions.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp)
                ) {
                    items(
                        items = subscriptions,
                        key = { it.id }
                    ) { subscription ->
                        SubscriptionCard(
                            subscription = subscription,
                            isUpdating = updatingId == subscription.id,
                            onRefresh = { viewModel.updateSubscription(subscription.id) },
                            onToggleEnabled = { viewModel.toggleEnabled(subscription) },
                            onToggleAutoUpdate = { viewModel.toggleAutoUpdate(subscription) },
                            onDelete = { showDeleteDialog = subscription }
                        )
                    }
                }
            }
        }
    }

    // ── دیالوگ افزودن اشتراک ──

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.hideAddDialog() },
            title = {
                Text(
                    text = "افزودن اشتراک",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = newSubName,
                        onValueChange = { viewModel.updateNewSubName(it) },
                        label = { Text("نام") },
                        placeholder = { Text("مثلاً: اشتراک من") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newSubUrl,
                        onValueChange = { viewModel.updateNewSubUrl(it) },
                        label = { Text("لینک اشتراک") },
                        placeholder = { Text("https://example.com/sub") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.addSubscription() },
                    enabled = viewModel.isAddFormValid()
                ) {
                    Text("افزودن")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.hideAddDialog() }) {
                    Text("لغو")
                }
            }
        )
    }

    // ── دیالوگ حذف اشتراک ──

    showDeleteDialog?.let { subscription ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = {
                Text(
                    text = "حذف اشتراک",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text("آیا مطمئنید \"${subscription.name}\" و تمام سرورهای مرتبط حذف شوند؟")
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteSubscription(subscription)
                    showDeleteDialog = null
                }) {
                    Text("حذف", color = Red500)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text("لغو")
                }
            }
        )
    }
}

// ══════════════════════════════════════════════════════════════
//  کارت اشتراک
// ══════════════════════════════════════════════════════════════

@Composable
private fun SubscriptionCard(
    subscription: Subscription,
    isUpdating: Boolean,
    onRefresh: () -> Unit,
    onToggleEnabled: () -> Unit,
    onToggleAutoUpdate: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // ── ردیف ۱: نام + وضعیت + دکمه حذف ──

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // نام
                        Text(
                            text = subscription.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        // بج غیرفعال
                        if (!subscription.isEnabled) {
                            Spacer(modifier = Modifier.width(8.dp))
                            StatusBadge(text = "غیرفعال", color = Gray500)
                        }

                        // بج منقضی
                        if (subscription.isExpired) {
                            Spacer(modifier = Modifier.width(4.dp))
                            StatusBadge(text = "منقضی", color = Red500)
                        }

                        // بج خطا
                        if (subscription.errorMessage != null) {
                            Spacer(modifier = Modifier.width(4.dp))
                            StatusBadge(text = "خطا", color = Orange500)
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // URL
                    Text(
                        text = subscription.url,
                        style = MaterialTheme.typography.bodySmall,
                        color = Gray500,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // دکمه حذف
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = Gray500,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ── ردیف ۲: اطلاعات ──

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                InfoItem(
                    label = "سرورها",
                    value = "${subscription.serverCount}"
                )

                InfoItem(
                    label = "بروزرسانی",
                    value = subscription.lastUpdatedDisplay
                )

                if (subscription.daysUntilExpiry != null) {
                    InfoItem(
                        label = "انقضا",
                        value = formatExpiry(subscription),
                        isWarning = (subscription.daysUntilExpiry ?: 0) <= 7
                    )
                }

                if (subscription.trafficTotal > 0) {
                    InfoItem(
                        label = "ترافیک",
                        value = subscription.trafficDisplay
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ── ردیف ۳: سوئیچ‌ها + بروزرسانی ──

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // سوئیچ فعال
                ToggleChip(
                    label = "فعال",
                    checked = subscription.isEnabled,
                    onCheckedChange = onToggleEnabled
                )

                Spacer(modifier = Modifier.width(12.dp))

                // سوئیچ بروزرسانی خودکار
                ToggleChip(
                    label = "خودکار",
                    checked = subscription.autoUpdate,
                    onCheckedChange = onToggleAutoUpdate
                )

                Spacer(modifier = Modifier.weight(1f))

                // دکمه بروزرسانی دستی
                IconButton(
                    onClick = onRefresh,
                    enabled = !isUpdating,
                    modifier = Modifier.size(36.dp)
                ) {
                    if (isUpdating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "بروزرسانی",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
//  کامپوننت‌های کمکی
// ══════════════════════════════════════════════════════════════

@Composable
private fun StatusBadge(text: String, color: androidx.compose.ui.graphics.Color) {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun InfoItem(
    label: String,
    value: String,
    isWarning: Boolean = false
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = if (isWarning) Orange500
            else MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Gray500
        )
    }
}

@Composable
private fun ToggleChip(
    label: String,
    checked: Boolean,
    onCheckedChange: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = Gray500
        )
        Spacer(modifier = Modifier.width(4.dp))
        Switch(
            checked = checked,
            onCheckedChange = { onCheckedChange() },
            colors = SwitchDefaults.colors(
                checkedTrackColor = Green500
            )
        )
    }
}

// ══════════════════════════════════════════════════════════════
//  حالت خالی
// ══════════════════════════════════════════════════════════════

@Composable
private fun EmptyState() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "اشتراکی اضافه نشده",
                style = MaterialTheme.typography.titleMedium,
                color = Gray500
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "روی + کلیک کنید تا لینک اشتراک اضافه کنید",
                style = MaterialTheme.typography.bodySmall,
                color = Gray500
            )
        }
    }
}

// ══════════════════════════════════════════════════════════════
//  ابزارها
// ══════════════════════════════════════════════════════════════

private fun formatExpiry(subscription: Subscription): String {
    val days = subscription.daysUntilExpiry ?: return "—"
    return when {
        days < 0  -> "منقضی شده"
        days == 0 -> "امروز"
        days == 1 -> "فردا"
        else      -> "$days روز"
    }
}
