package com.reza.iranproxy.ui.theme

import androidx.compose.ui.graphics.Color

// ── Primary ──
val Blue500 = Color(0xFF2196F3)
val Blue700 = Color(0xFF1976D2)
val Blue200 = Color(0xFF90CAF9)

// ── Secondary ──
val Teal200 = Color(0xFF03DAC5)
val Teal700 = Color(0xFF018786)

// ── Background ──
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceVariant = Color(0xFF2C2C2C)

// ── Text ──
val White = Color(0xFFFFFFFF)
val Gray100 = Color(0xFFF5F5F5)
val Gray300 = Color(0xFFE0E0E0)
val Gray500 = Color(0xFF9E9E9E)
val Gray700 = Color(0xFF616161)

// ── Status ──
val Green500 = Color(0xFF4CAF50)
val Green700 = Color(0xFF388E3C)
val Red500 = Color(0xFFF44336)
val Red700 = Color(0xFFD32F2F)
val Orange500 = Color(0xFFFF9800)
val Yellow500 = Color(0xFFFFEB3B)

// ── Protocol Colors ──
val VmessColor = Color(0xFF2196F3)
val VlessColor = Color(0xFF4CAF50)
val SsColor = Color(0xFFFF9800)
val TrojanColor = Color(0xFFE91E63)
val RealityColor = Color(0xFF9C27B0)
