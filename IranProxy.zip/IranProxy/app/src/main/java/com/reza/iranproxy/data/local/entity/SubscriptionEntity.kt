package com.reza.iranproxy.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "subscriptions",
    indices = [
        Index("url", unique = true)
    ]
)
data class SubscriptionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "url")
    val url: String,

    @ColumnInfo(name = "token")
    val token: String = "",

    @ColumnInfo(name = "user_agent")
    val userAgent: String = "",

    @ColumnInfo(name = "server_count")
    val serverCount: Int = 0,

    @ColumnInfo(name = "auto_update")
    val autoUpdate: Boolean = true,

    @ColumnInfo(name = "last_updated")
    val lastUpdated: Long = 0L,

    @ColumnInfo(name = "expires_at")
    val expiresAt: Long? = null,

    @ColumnInfo(name = "traffic_used")
    val trafficUsed: Long = 0L,

    @ColumnInfo(name = "traffic_total")
    val trafficTotal: Long = 0L,

    @ColumnInfo(name = "is_enabled")
    val isEnabled: Boolean = true,

    @ColumnInfo(name = "error_message")
    val errorMessage: String? = null,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)
