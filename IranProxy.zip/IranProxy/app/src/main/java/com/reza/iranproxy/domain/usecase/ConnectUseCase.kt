package com.reza.iranproxy.domain.usecase

import com.reza.iranproxy.domain.model.ConnectionStatus
import com.reza.iranproxy.domain.model.Server
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConnectUseCase {

    private val _status = MutableStateFlow<ConnectionStatus>(ConnectionStatus.Disconnected)
    val status: StateFlow<ConnectionStatus> = _status.asStateFlow()

    suspend operator fun invoke(server: Server): Result<Unit> {
        if (_status.value.isConnecting) {
            return Result.failure(IllegalStateException("در حال اتصال هستید"))
        }

        if (_status.value.isConnected) {
            return Result.failure(IllegalStateException("از قبل متصل هستید"))
        }

        _status.value = ConnectionStatus.Connecting(
            serverId = server.id,
            serverName = server.name
        )

        return try {
            // TODO: اتصال واقعی به Xray Core
            // ۱. ساخت کانفیگ JSON از اطلاعات سرور
            // ۲. استارت Xray Core
            // ۳. باز کردن VPN Tunnel
            // ۴. بررسی وضعیت اتصال

            _status.value = ConnectionStatus.Connected(
                serverId = server.id,
                serverName = server.name
            )
            Result.success(Unit)
        } catch (e: Exception) {
            _status.value = ConnectionStatus.Error(
                serverId = server.id,
                message = e.message ?: "خطای ناشناخته در اتصال"
            )
            Result.failure(e)
        }
    }

    fun reset() {
        _status.value = ConnectionStatus.Disconnected
    }
}
