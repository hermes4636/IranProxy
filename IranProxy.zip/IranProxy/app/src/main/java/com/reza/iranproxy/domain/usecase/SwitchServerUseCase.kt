package com.reza.iranproxy.domain.usecase

import com.reza.iranproxy.data.repository.ServerRepository
import com.reza.iranproxy.domain.model.ConnectionStatus
import com.reza.iranproxy.domain.model.Server

class SwitchServerUseCase(
    private val serverRepository: ServerRepository,
    private val connectUseCase: ConnectUseCase,
    private val disconnectUseCase: DisconnectUseCase
) {

    suspend operator fun invoke(server: Server): Result<Unit> {
        val currentStatus = connectUseCase.status.value

        // اگه متصله، اول قطع کن
        if (currentStatus.isConnected) {
            disconnectUseCase.getOrThrow()
        }

        // سرور جدید رو فعال کن
        serverRepository.switchToServer(server.id)

        // وصل شو
        return connectUseCase(server)
    }

    suspend fun toBestAvailable(): Result<Unit> {
        val bestServer = serverRepository.getBestByLatency(1)
            .firstOrNull()

        if (bestServer == null) {
            return Result.failure(
                IllegalStateException("سرور مناسبی یافت نشد")
            )
        }

        return invoke(bestServer)
    }

    suspend fun toServerById(serverId: Long): Result<Unit> {
        val server = serverRepository.getById(serverId)
            ?: return Result.failure(
                IllegalArgumentException("سرور یافت نشد: $serverId")
            )
        return invoke(server)
    }
}
