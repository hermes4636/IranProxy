package com.reza.iranproxy.domain.usecase

import com.reza.iranproxy.data.repository.ServerRepository
import com.reza.iranproxy.domain.model.Server
import com.reza.iranproxy.domain.model.ServerProtocol

class ImportServerUseCase(
    private val serverRepository: ServerRepository
) {

    // ── افزودن سرور دستی ──

    suspend fun fromManualInput(
        name: String,
        address: String,
        port: Int,
        protocol: ServerProtocol,
        uuid: String = "",
        alterId: Int = 0,
        password: String = "",
        security: String = "",
        network: String = "tcp",
        tls: String = "none",
        sni: String = "",
        fingerprint: String = "chrome",
        alpn: String = "",
        flow: String = "",
        realityPublicKey: String = "",
        realityShortId: String = "",
        subscriptionId: Long? = null
    ): Result<Server> {
        // اعتبارسنجی
        if (name.isBlank()) {
            return Result.failure(IllegalArgumentException("نام سرور نمی‌تواند خالی باشد"))
        }
        if (address.isBlank()) {
            return Result.failure(IllegalArgumentException("آدرس سرور نمی‌تواند خالی باشد"))
        }
        if (port !in 1..65535) {
            return Result.failure(IllegalArgumentException("پورت نامعتبر است"))
        }
        if (protocol == ServerProtocol.VMESS || protocol == ServerProtocol.VLESS) {
            if (uuid.isBlank()) {
                return Result.failure(IllegalArgumentException("UUID برای ${protocol.displayName} الزامی است"))
            }
        }

        val server = Server(
            name = name,
            address = address,
            port = port,
            protocol = protocol,
            uuid = uuid,
            alterId = alterId,
            password = password,
            security = security,
            network = network,
            tls = tls,
            sni = sni,
            fingerprint = fingerprint,
            alpn = alpn,
            flow = flow,
            realityPublicKey = realityPublicKey,
            realityShortId = realityShortId,
            subscriptionId = subscriptionId
        )

        val id = serverRepository.insert(toEntity(server))
        return Result.success(server.copy(id = id))
    }

    // ── از لینک اشتراک ──

    suspend fun fromSubscriptionUrl(url: String): Result<List<Server>> {
        if (url.isBlank()) {
            return Result.failure(IllegalArgumentException("لینک اشتراک نمی‌تواند خالی باشد"))
        }

        return try {
            // TODO: دریافت و پارس لینک اشتراک
            // ۱. HTTP GET روی لینک
            // ۲. پارس response (Base64 decode)
            // ۳. پارس هر خط (vmess://, vless://, ss://, trojan://)
            // ۴. تبدیل به لیست Server

            val servers = emptyList<Server>()
            serverRepository.insertAll(servers.map { toEntity(it) })
            Result.success(servers)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── از لینک تکی ──

    suspend fun fromShareLink(link: String): Result<Server> {
        if (link.isBlank()) {
            return Result.failure(IllegalArgumentException("لینک نمی‌تواند خالی باشد"))
        }

        return try {
            // TODO: پارس لینک اشتراکی
            // vmess://eyJhZGQ...
            // vless://uuid@address:port?...
            // ss://base64@address:port
            // trojan://password@address:port

            val server = parseShareLink(link)
            val id = serverRepository.insert(toEntity(server))
            Result.success(server.copy(id = id))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── از QR Code ──

    suspend fun fromQrCode(qrContent: String): Result<Server> {
        return fromShareLink(qrContent)
    }

    // ── Helpers ──

    private fun parseShareLink(link: String): Server {
        // TODO: پیاده‌سازی واقعی پارسر
        throw NotImplementedError("پارسر لینک هنوز پیاده‌سازی نشده")
    }

    private fun toEntity(server: Server): com.reza.iranproxy.data.local.entity.ServerEntity {
        return com.reza.iranproxy.data.local.entity.ServerEntity(
            id = server.id,
            name = server.name,
            address = server.address,
            port = server.port,
            protocol = server.protocol.name,
            uuid = server.uuid,
            alterId = server.alterId,
            password = server.password,
            security = server.security,
            network = server.network,
            headerType = server.headerType,
            host = server.host,
            path = server.path,
            tls = server.tls,
            sni = server.sni,
            fingerprint = server.fingerprint,
            alpn = server.alpn,
            flow = server.flow,
            realityPublicKey = server.realityPublicKey,
            realityShortId = server.realityShortId,
            subscriptionId = server.subscriptionId
        )
    }
}
