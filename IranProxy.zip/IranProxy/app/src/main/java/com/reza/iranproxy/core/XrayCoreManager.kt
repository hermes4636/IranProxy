package com.reza.iranproxy.core

import android.content.Context
import com.reza.iranproxy.domain.model.Server
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

class XrayCoreManager(
    private val context: Context
) {

    // ── State ──

    sealed class CoreState {
        data object Idle : CoreState()
        data object Starting : CoreState()
        data object Running : CoreState()
        data class Error(val message: String) : CoreState()
    }

    private val _state = MutableStateFlow<CoreState>(CoreState.Idle)
    val state: StateFlow<CoreState> = _state.asStateFlow()

    private var coreProcess: Process? = null
    private var configFile: File? = null

    // ── Start ──

    suspend fun start(server: Server): Result<Unit> = withContext(Dispatchers.IO) {
        if (_state.value is CoreState.Running) {
            return@withContext Result.failure(
                IllegalStateException("Core در حال اجراست")
            )
        }

        _state.value = CoreState.Starting

        try {
            // ۱. ساخت کانفیگ
            val configJson = XrayConfigBuilder.build(server)
            configFile = writeConfigFile(configJson)

            // ۲. پیدا کردن باینری xray
            val coreBinary = getCoreBinaryPath()
            if (!File(coreBinary).exists()) {
                throw IllegalStateException("باینری Xray پیدا نشد: $coreBinary")
            }

            // ۳. اجرای core
            val process = ProcessBuilder(
                coreBinary,
                "run",
                "-c", configFile!!.absolutePath
            )
                .directory(context.filesDir)
                .redirectErrorStream(true)
                .start()

            coreProcess = process

            // ۴. بررسی وضعیت
            Thread.sleep(500)
            if (process.isAlive) {
                _state.value = CoreState.Running
                Result.success(Unit)
            } else {
                val error = process.errorStream.bufferedReader().readText()
                throw IllegalStateException("Core شروع نشد: $error")
            }
        } catch (e: Exception) {
            _state.value = CoreState.Error(e.message ?: "خطای ناشناخته")
            stop()
            Result.failure(e)
        }
    }

    // ── Stop ──

    suspend fun stop(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            coreProcess?.let { process ->
                if (process.isAlive) {
                    process.destroy()

                    // صبر برای بسته شدن
                    val terminated = process.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)
                    if (!terminated) {
                        process.destroyForcibly()
                    }
                }
            }
            coreProcess = null

            // پاک کردن کانفیگ موقت
            configFile?.delete()
            configFile = null

            _state.value = CoreState.Idle
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── Status ──

    fun isRunning(): Boolean {
        return _state.value is CoreState.Running
    }

    fun getCurrentState(): CoreState = _state.value

    // ── Restart ──

    suspend fun restart(server: Server): Result<Unit> {
        stop()
        return start(server)
    }

    // ── Helpers ──

    private fun writeConfigFile(config: String): File {
        val configFile = File(context.filesDir, "xray_config.json")
        configFile.writeText(config)
        return configFile
    }

    private fun getCoreBinaryPath(): String {
        // اول از assets، بعد از پوشه files
        val internalPath = File(context.filesDir, "xray")
        if (internalPath.exists()) {
            return internalPath.absolutePath
        }

        // از lib پوشه
        val libPath = File(context.applicationInfo.nativeLibraryDir, "libxray.so")
        if (libPath.exists()) {
            return libPath.absolutePath
        }

        return "xray"
    }

    // ── Extract Assets ──

    suspend fun extractCore(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val destFile = File(context.filesDir, "xray")
            if (destFile.exists()) {
                return@withContext Result.success(Unit)
            }

            // استخراج از assets (اگه وجود داشته باشه)
            // در غیر این صورت از lib folder استفاده میشه
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
