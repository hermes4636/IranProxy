package com.reza.iranproxy.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "routing_rules",
    indices = [
        Index("outbound"),
        Index("is_enabled"),
        Index("priority")
    ]
)
data class RoutingRuleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "name")
    val name: String,

    // DOMAIN, DOMAIN-SUFFIX, DOMAIN-KEYWORD,
    // IP-CIDR, IP-CIDR6, GEOIP, GEOSITE,
    // PROCESS-NAME, PROCESS-PATH
    @ColumnInfo(name = "type")
    val type: String,

    // مثال: "google.com", "ir", "192.168.0.0/16"
    @ColumnInfo(name = "value")
    val value: String,

    // direct, proxy, block, dns
    @ColumnInfo(name = "outbound")
    val outbound: String = "direct",

    @ColumnInfo(name = "is_enabled")
    val isEnabled: Boolean = true,

    @ColumnInfo(name = "priority")
    val priority: Int = 0,

    @ColumnInfo(name = "remove_from_direct")
    val removeFromDirect: Boolean = false,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)
