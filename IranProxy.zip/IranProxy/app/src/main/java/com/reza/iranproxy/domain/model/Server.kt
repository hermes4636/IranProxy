package com.reza.iranproxy.domain.model

data class Server(
    val id: Long = 0,
    val name: String,
    val address: String,
    val port: Int,
    val protocol: ServerProtocol,
    val uuid: String = "",
    val alterId: Int = 0,
    val password: String = "",
    val security: String = "",
    val network: String = "tcp",
    val headerType: String = "none",
    val host: String = "",
    val path: String = "",
    val tls: String = "none",
    val sni: String = "",
    val fingerprint: String = "chrome",
    val alpn: String = "",
    val flow: String = "",
    val realityPublicKey: String = "",
    val realityShortId: String = "",
    val subscriptionId: Long? = null,
    val isActive: Boolean = false,
    val isFavorite: Boolean = false,
    val latency: Long = -1L,
    val trafficUsed: Long = 0L,
    val trafficTotal: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val latencyDisplay: String
        get() = when {
            latency < 0 -> "---"
            latency == 0L -> "Timeout"
            else -> "${latency}ms"
        }

    val trafficDisplay: String
        get() {
            if (trafficTotal == 0L) return formatBytes(trafficUsed)
            return "${formatBytes(trafficUsed)} / ${formatBytes(trafficTotal)}"
        }

    val protocolDisplayName: String
        get() = protocol.displayName

    val tlsDisplayName: String
        get() = when (tls) {
            "reality" -> "Reality"
            "tls" -> "TLS"
            else -> "None"
        }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        if (bytes < 1024 * 1024) return "${bytes / 1024} KB"
        if (bytes < 1024 * 1024 * 1024) return "${bytes / (1024 * 1024)} MB"
        return "${bytes / (1024 * 1024 * 1024)} GB"
    }
}
