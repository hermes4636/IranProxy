# ═══════════════════════════════════════════════════════
#  IranProxy — ProGuard / R8 Rules
# ═══════════════════════════════════════════════════════

# ── Room ──
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao interface *
-dontwarn androidx.room.paging.**

# ── Hilt ──
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }

# ── Xray / Go Mobile ──
-keep class libv2ray.** { *; }
-keep class com.reza.iranproxy.core.** { *; }

# ── Data classes ──
-keep class com.reza.iranproxy.data.local.entity.** { *; }
-keep class com.reza.iranproxy.domain.model.** { *; }

# ── Coroutines ──
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# ── Compose ──
-dontwarn androidx.compose.**

# ── General ─-optimizations
-repackageclasses ''
-allowaccessmodification
-overloadaggressively
